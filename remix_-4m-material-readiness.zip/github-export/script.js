// Material Shortage Reconciliation Engine - Main Application Script

// 1. STATE MANAGEMENT
let excelFiles = [];
let emailData = {
  pns: [],
  mmos: [],
  rawPns: '',
  rawMmos: '',
  pnToMmoMap: {}
};
let locale = 'en'; // Default to English, instantly switchable
let caseSensitive = false;
let resultsViewTab = 'report'; // 'report' or 'database'
let activeExcelFileId = null;
let excelSheets = {}; // Map of fileId to { data: [[]], headers: [] }
let showCustomizePanel = false;

// Active MMO tab for the executive report slide
let activeMmoTab = '';

// Custom summary report slide values
let customReportTitle = '';
let customReportBomRef = '';
let customReportPeriod = '';
let customReportDate = '';
let customReportBullet1 = '';
let customReportBullet2 = '';
let customReportBullet3 = '';

// 2. BILINGUAL TRANSLATIONS DICTIONARY
const translations = {
  header_title: {
    th: 'เครื่องมือกระทบยอดและวิเคราะห์ข้อมูล SHORTAGE',
    en: 'RECONCILIATION ANALYTICS TOOL'
  },
  header_subtitle: {
    th: 'ระบบจับคู่ตรวจสอบรายการของขาดระหว่าง EXCEL และ อีเมล',
    en: 'Excel shortage vs Email shortage matching engine'
  },
  case_sensitive: {
    th: 'ตัวพิมพ์เล็ก-ใหญ่ตรงกัน',
    en: 'CASE-SENSITIVE'
  },
  demo_data: {
    th: 'ชุดข้อมูลตัวอย่าง',
    en: 'DEMO DATA'
  },
  decision_matrix: {
    th: 'สูตรและตรรกะการวิเคราะห์ข้อมูล',
    en: 'Decisions formula Matrix'
  },
  comparison_rule_set: {
    th: 'ตารางวิเคราะห์ความสอดคล้องของข้อมูล',
    en: 'Comparison rule-set logic'
  },
  need_to_check: {
    th: 'ต้องตรวจสอบ (Need to Check)',
    en: 'Need to Check'
  },
  need_to_check_desc: {
    th: 'PN อยู่ใน Email + อยู่ใน Excel + ยอด Short > 0',
    en: 'PN in email + in Excel + Short > 0'
  },
  status_2nd: {
    th: 'ขาดแคลนเฉพาะใน Email (2nd)',
    en: '2nd'
  },
  status_2nd_desc: {
    th: 'PN อยู่ใน Email แต่ไม่อยู่ใน Excel (0 PN)',
    en: 'PN in email but not in Excel'
  },
  status_good: {
    th: 'ปกติ (Good/NR)',
    en: 'Good/NR'
  },
  status_good_desc: {
    th: 'อื่นๆ (เช่น ไม่อยู่ใน Email หรือยอด Short <= 0)',
    en: 'Others (e.g. not in email or ShortQty <= 0)'
  },
  excel_source: {
    th: '1. แหล่งข้อมูล: รายการของขาดจาก EXCEL',
    en: '1. SOURCE: EXCEL SHORTAGE'
  },
  excel_sub: {
    th: 'จับคู่คอลัมน์ข้อมูล PN, SHORTQTY, MMO',
    en: 'PN, SHORTQTY, MMO FIELDS'
  },
  excel_paste: {
    th: 'วางแถวข้อมูลจากคลิปบอร์ด',
    en: 'PASTE ROWS TO CREATE NEW SOURCE'
  },
  excel_upload: {
    th: 'อัปโหลดไฟล์รายการของขาด (รองรับหลายไฟล์)',
    en: 'UPLOAD SHORTAGE FILES (SUPPORTS MULTIPLE)'
  },
  excel_upload_sub: {
    th: 'อัปโหลดไฟล์ EXCEL / CSV',
    en: 'UPLOAD EXCEL / CSV FILES'
  },
  excel_drag_drop: {
    th: 'ลากไฟล์มาวางที่นี่ หรือคลิกเพื่อเลือกไฟล์',
    en: 'Drop multiple files or click to browse'
  },
  excel_manage: {
    th: 'จัดการแหล่งข้อมูล',
    en: 'MANAGE SOURCES'
  },
  clear_all: {
    th: 'ล้างข้อมูลทั้งหมด',
    en: 'CLEAR ALL'
  },
  rows: {
    th: 'แถว',
    en: 'rows'
  },
  active: {
    th: 'กำลังใช้งาน',
    en: 'Active'
  },
  map_pn: {
    th: 'รหัสพาร์ท (PN)',
    en: 'Part Number (PN)'
  },
  map_qty: {
    th: 'จำนวนที่ขาด (ShortQty)',
    en: 'Short Qty'
  },
  map_mmo: {
    th: 'รหัสใบสั่งงาน (MMO)',
    en: 'MMO'
  },
  map_desc: {
    th: 'รายละเอียดพาร์ท (Part Description)',
    en: 'Part Description'
  },
  column_mapping: {
    th: 'การจับคู่คอลัมน์ข้อมูล (Column Mapping)',
    en: 'Interactive Column Mapping'
  },
  no_excel_title: {
    th: 'ไม่พบแหล่งข้อมูลของขาดจาก Excel',
    en: 'No Excel Shortage Sources Loaded'
  },
  no_excel_sub: {
    th: 'ลากและวางไฟล์ Excel, วางข้อมูลข้อความ หรือคลิก "ข้อมูลตัวอย่าง" ด้านบนเพื่อจำลองยอดของขาด!',
    en: 'Drag and drop excel files, paste text data, or click "Demo Data" at the top to load simulation shortages!'
  },
  add_row: {
    th: 'เพิ่มแถว',
    en: 'Add Row'
  },
  rows_editor_title: {
    th: 'เครื่องมือแก้ไขแถวข้อมูล',
    en: 'Active Rows Editor'
  },
  email_source: {
    th: '2. แหล่งข้อมูล: รายการของขาดจากอีเมล',
    en: '2. SOURCE: EMAIL SHORTAGE'
  },
  email_sub: {
    th: 'ดึงข้อมูลพาร์ทจากไฟล์ .MSG / .EML หรือวางข้อความโดยตรง',
    en: 'EXTRACT DIRECTLY FROM .MSG / .EML OR PASTE'
  },
  email_upload: {
    th: 'อัปโหลดไฟล์อีเมล (.MSG / .EML)',
    en: 'UPLOAD EMAIL FILES (.MSG / .EML)'
  },
  email_drag_drop: {
    th: 'ลากไฟล์ .msg / .eml มาวาง หรือคลิกเพื่อค้นหาไฟล์',
    en: 'Drop .msg / .eml files or click to browse'
  },
  extracted_mmos: {
    th: 'รหัส MMO ที่พบในอีเมล',
    en: 'EXTRACTED MMO CODES'
  },
  extracted_pns: {
    th: 'รหัสพาร์ท (PN) ที่พบในอีเมล',
    en: 'EXTRACTED PART NUMBERS'
  },
  unique_pns: {
    th: 'พาร์ทที่เป็นเอกลักษณ์',
    en: 'unique PNs'
  },
  unique_mmos: {
    th: 'MMO ที่เป็นเอกลักษณ์',
    en: 'unique MMOs'
  },
  decision_formula_ref: {
    th: 'สูตรตรรกะประเมินสถานะความพร้อมชิ้นส่วน:',
    en: 'Decision Formula Reference:'
  },
  rule_not_reported: {
    th: 'ไม่ได้ระบุใบสั่งผลิต',
    en: 'Not reported'
  },
  rule_critical: {
    th: 'วิกฤต/ต้องตรวจสอบ',
    en: 'Critical'
  },
  rule_conflict: {
    th: 'ขัดแย้ง',
    en: 'Conflict'
  },
  rule_balanced: {
    th: 'ปกติ/สมดุล',
    en: 'Balanced'
  },
  results_title: {
    th: '3. ผลลัพธ์และรายงานการตรวจสอบกระทบยอด',
    en: '3. MATCHING ENGINE RESULTS & REPORTS'
  },
  results_sub: {
    th: 'ระบบตรวจสอบกระทบยอดความสอดคล้องความหนาแน่นสูง',
    en: 'HIGH DENSITY RECONCILIATION AUDIT'
  },
  tab_report: {
    th: '📋 รายงานผู้บริหาร',
    en: '📋 Corporate Report'
  },
  tab_database: {
    th: '📊 ตารางฐานข้อมูล',
    en: '📊 Status Matrix'
  },
  btn_copy: {
    th: 'คัดลอก',
    en: 'Copy'
  },
  btn_pdf: {
    th: 'ส่งออก PDF',
    en: 'PDF Report'
  },
  awaiting_inputs: {
    th: 'รอข้อมูลเพื่อทำการกระทบยอด',
    en: 'Awaiting inputs for matching'
  },
  awaiting_inputs_sub: {
    th: 'กรุณาอัปโหลดหรือระบุข้อมูลความต้องการชิ้นส่วนทั้งสองแผงด้านบนเพื่อเปรียบเทียบข้อมูล!',
    en: 'Please insert shortage details in both panels above to auto-generate this comparison report.'
  },
  select_mmo_tab: {
    th: '📂 เลือกชุดรายงานตามกลุ่มใบสั่งผลิต MMO:',
    en: '📂 Select Report Set by MMO Group:'
  },
  btn_customize: {
    th: '🛠️ ปรับแต่งรายละเอียด & บทสรุปรายงาน PDF',
    en: '🛠️ Customize PDF Report Details & Summary'
  },
  slide_metadata: {
    th: 'ข้อมูลประกอบสไลด์ (Metadata)',
    en: 'Slide Metadata'
  },
  executive_bullets: {
    th: 'ประเด็นสรุปสำหรับผู้บริหาร (Executive Summary Bullet Points)',
    en: 'Executive Summary Bullet Points'
  },
  live_preview: {
    th: 'พรีวิวสด: หน้าสไลด์รายงาน PDF',
    en: 'Live Preview: PDF document slides'
  },
  slide_preview_title: {
    th: 'รายงานความพร้อมชิ้นส่วน 4M',
    en: '4M Material Readiness Report'
  },
  slide_date_lbl: {
    th: 'วันที่ออกรายงาน:',
    en: 'Generated:'
  },
  slide_bom_lbl: {
    th: 'รหัสอ้างอิง BOM/MMO:',
    en: 'BOM Reference:'
  },
  kpi_total: {
    th: 'รายการตรวจสอบรวม',
    en: 'Total Reconciled'
  },
  kpi_total_desc: {
    th: 'รายการของขาดที่ยืนยัน',
    en: 'Shortage Items Verified'
  },
  kpi_critical: {
    th: 'ต้องตรวจสอบ (1st)',
    en: 'Need to Check'
  },
  kpi_critical_desc: {
    th: 'รายการของขาดตรงกัน',
    en: 'Critical deficit matching'
  },
  kpi_healthy: {
    th: 'ปกติ / NR',
    en: 'Good / NR'
  },
  kpi_healthy_desc: {
    th: 'รายการปกติเสถียร',
    en: 'Reported balanced shortages'
  },
  slide_findings_header: {
    th: 'บทสรุปผู้บริหารและข้อค้นพบ',
    en: 'Executive Summary Findings'
  },
  slide_ratio_title: {
    th: 'สัดส่วนและสถานะการตรวจสอบ',
    en: 'Status Share Distribution'
  },
  slide_analysis: {
    th: 'บทวิเคราะห์ทางเทคนิคสำหรับผู้บริหาร',
    en: 'Detailed Analysis Narrative'
  },
  slide_footer_left: {
    th: 'ระบบเปรียบเทียบข้อมูล SHORTAGE • รายงานกระทบยอดความละเอียดสูง',
    en: 'PROCUREMENT RECONCILIATION ANALYTICS ENGINE'
  },
  filter_lbl: {
    th: 'กรองสถานะ:',
    en: 'Filter by Status:'
  },
  opt_all_status: {
    th: 'ทุกสถานะ',
    en: 'All Statuses'
  },
  showing: {
    th: 'แสดงข้อมูล',
    en: 'Showing'
  },
  of: {
    th: 'จากทั้งหมด',
    en: 'of'
  },
  records: {
    th: 'รายการ',
    en: 'records'
  },
  footer_text: {
    th: 'ระบบเปรียบเทียบข้อมูล Shortage • รายงานกระทบยอดความละเอียดสูงฝ่ายจัดซื้อจัดจ้าง',
    en: 'Shortage Comparator Engine • High Density Procurement reconciliation report'
  },
  unknown_mmo: {
    th: 'ใบสั่งงานอื่น/ไม่ระบุ (Unknown MMO)',
    en: 'Unknown MMO'
  }
};

// 3. INITIALIZATION & EVENTS
window.addEventListener('DOMContentLoaded', () => {
  // Bind standard layout elements and drag events
  initializeDragAndDrop();
  initializeTextareaTriggers();
  
  // Render initial translations
  updateUI();
  
  // Run Lucide Icons replacement
  lucide.createIcons();
});

// UI update routine to change all language tokens
function updateUI() {
  const dictionary = translations;
  
  // Header & Controls
  setElementText('txt-header-title', dictionary.header_title[locale]);
  setElementText('txt-header-subtitle', dictionary.header_subtitle[locale]);
  setElementText('txt-case-sensitive', dictionary.case_sensitive[locale]);
  setElementText('txt-demo-data', dictionary.demo_data[locale]);
  
  // Explanation Matrix
  setElementText('txt-decision-matrix', dictionary.decision_matrix[locale]);
  setElementText('txt-comparison-rule-set', dictionary.comparison_rule_set[locale]);
  setElementText('txt-need-to-check-label', '🔴 ' + dictionary.need_to_check[locale]);
  setElementText('txt-need-to-check-desc', dictionary.need_to_check_desc[locale]);
  setElementText('txt-status-2nd-label', '🟡 ' + dictionary.status_2nd[locale]);
  setElementText('txt-status-2nd-desc', dictionary.status_2nd_desc[locale]);
  setElementText('txt-status-good-label', '🟢 ' + dictionary.status_good[locale]);
  setElementText('txt-status-good-desc', dictionary.status_good_desc[locale]);

  // Excel Source Card
  setElementText('txt-excel-source', dictionary.excel_source[locale]);
  setElementText('txt-excel-sub', dictionary.excel_sub[locale]);
  setElementText('txt-clear-all-excel', dictionary.clear_all[locale]);
  setElementText('txt-excel-paste', dictionary.excel_paste[locale]);
  setElementText('txt-excel-upload', dictionary.excel_upload[locale]);
  setElementText('txt-excel-upload-sub', dictionary.excel_upload_sub[locale]);
  setElementText('txt-excel-drag-drop', dictionary.excel_drag_drop[locale]);
  setElementText('txt-no-excel-title', dictionary.no_excel_title[locale]);
  setElementText('txt-no-excel-sub', dictionary.no_excel_sub[locale]);
  setElementText('txt-add-row', dictionary.add_row[locale]);
  setElementText('txt-rows-editor-title', dictionary.rows_editor_title[locale]);
  setElementText('txt-configuring-file', (locale === 'th' ? 'กำลังกำหนดค่าไฟล์' : 'Configuring File') + ':');
  setElementText('txt-rows-count', dictionary.rows[locale]);
  setElementText('txt-column-mapping', dictionary.column_mapping[locale]);
  
  // Table column headers
  setElementText('col-h-pn', dictionary.map_pn[locale]);
  setElementText('col-h-desc', dictionary.map_desc[locale]);
  setElementText('col-h-qty', dictionary.map_qty[locale]);
  setElementText('col-h-mmo', dictionary.map_mmo[locale]);
  setElementText('col-h-del', locale === 'th' ? 'ลบ' : 'Del');
  
  setElementText('txt-map-pn', dictionary.map_pn[locale]);
  setElementText('txt-map-desc', dictionary.map_desc[locale]);
  setElementText('txt-map-qty', dictionary.map_qty[locale]);
  setElementText('txt-map-mmo', dictionary.map_mmo[locale]);

  // Email Card
  setElementText('txt-email-source', dictionary.email_source[locale]);
  setElementText('txt-email-sub', dictionary.email_sub[locale]);
  setElementText('txt-clear-all-email-btn', dictionary.clear_all[locale]);
  setElementText('txt-email-uploaded-files-label', dictionary.email_upload[locale]);
  setElementText('txt-email-upload-sub', locale === 'th' ? 'อัปโหลดไฟล์อีเมล' : 'UPLOAD EMAIL FILES');
  setElementText('txt-email-drag-drop', dictionary.email_drag_drop[locale]);
  setElementText('txt-uploaded-files-title', locale === 'th' ? 'ไฟล์ที่อัปโหลดแล้ว' : 'Uploaded Files');
  setElementText('txt-extracted-pns', dictionary.extracted_pns[locale]);
  setElementText('txt-extracted-mmos', dictionary.extracted_mmos[locale]);
  setElementText('txt-unique-pns', locale === 'th' ? 'พาร์ทที่เป็นเอกลักษณ์' : 'unique PNs');
  setElementText('txt-unique-mmos', locale === 'th' ? 'MMO ที่เป็นเอกลักษณ์' : 'unique MMOs');
  setElementText('txt-decision-formula-ref', dictionary.decision_formula_ref[locale]);
  setElementText('txt-rule-not-reported', dictionary.rule_not_reported[locale]);
  setElementText('txt-rule-critical', dictionary.rule_critical[locale]);
  setElementText('txt-rule-conflict', dictionary.rule_conflict[locale]);
  setElementText('txt-rule-balanced', dictionary.rule_balanced[locale]);
  
  // Results Display Card
  setElementText('txt-results-title', dictionary.results_title[locale]);
  setElementText('txt-results-sub', dictionary.results_sub[locale]);
  setElementText('txt-tab-report', locale === 'th' ? '📋 รายงานผู้บริหาร' : '📋 Corporate Report');
  setElementText('txt-tab-database', locale === 'th' ? '📊 ตารางฐานข้อมูล' : '📊 Status Matrix');
  setElementText('txt-btn-copy', locale === 'th' ? 'คัดลอก' : 'Copy');
  setElementText('txt-btn-pdf', locale === 'th' ? 'ส่งออก PDF' : 'PDF Report');
  setElementText('txt-awaiting-inputs', dictionary.awaiting_inputs[locale]);
  setElementText('txt-awaiting-inputs-sub', dictionary.awaiting_inputs_sub[locale]);
  setElementText('txt-select-mmo-tab', dictionary.select_mmo_tab[locale]);
  setElementText('txt-btn-customize', dictionary.btn_customize[locale]);
  setElementText('txt-slide-metadata', dictionary.slide_metadata[locale]);
  setElementText('txt-executive-bullets', dictionary.executive_bullets[locale]);
  setElementText('txt-live-preview', dictionary.live_preview[locale]);
  setElementText('slide-preview-title', dictionary.slide_preview_title[locale]);
  setElementText('txt-slide-date-lbl', dictionary.slide_date_lbl[locale]);
  setElementText('txt-slide-bom-lbl', dictionary.slide_bom_lbl[locale]);
  setElementText('txt-kpi-total', dictionary.kpi_total[locale]);
  setElementText('txt-kpi-total-desc', dictionary.kpi_total_desc[locale]);
  setElementText('txt-kpi-critical', dictionary.kpi_critical[locale]);
  setElementText('txt-kpi-critical-desc', dictionary.kpi_critical_desc[locale]);
  setElementText('txt-kpi-healthy', dictionary.kpi_healthy[locale]);
  setElementText('txt-kpi-healthy-desc', dictionary.kpi_healthy_desc[locale]);
  setElementText('txt-slide-findings-header', dictionary.slide_findings_header[locale]);
  setElementText('txt-slide-ratio-title', dictionary.slide_ratio_title[locale]);
  setElementText('txt-slide-analysis', dictionary.slide_analysis[locale]);
  setElementText('txt-slide-footer-left', dictionary.slide_footer_left[locale]);
  
  // Database filter block
  setElementText('txt-filter-lbl', dictionary.filter_lbl[locale]);
  setElementText('opt-all-status', dictionary.opt_all_status[locale]);
  setElementText('db-h-pn', dictionary.map_pn[locale]);
  setElementText('db-h-desc', dictionary.map_desc[locale]);
  setElementText('db-h-qty', dictionary.map_qty[locale]);
  setElementText('db-h-mmo', dictionary.map_mmo[locale]);
  setElementText('db-h-status', locale === 'th' ? 'สถานะ' : 'STATUS');
  setElementText('txt-showing', dictionary.showing[locale]);
  setElementText('txt-of', dictionary.of[locale]);
  setElementText('txt-records', dictionary.records[locale]);
  
  setElementText('txt-footer-text', dictionary.footer_text[locale]);

  // Placeholders
  const textareas = {
    'excel-paste-textarea': locale === 'th' 
      ? 'วางข้อมูลแถวจาก Excel คัดลอกแบบมีหัวตาราง (Tab-delimited)... เช่น\nPN\tShortQty\tMMO' 
      : 'Paste spreadsheet rows here (with headers)... e.g.\nPN\tShortQty\tMMO',
    'email-pns-textarea': locale === 'th'
      ? 'หรือแก้ไขรหัสพาร์ทในอีเมล (คั่นด้วยบรรทัดใหม่หรือจุลภาค)...'
      : 'Or Paste/Edit Email PNs (newline or comma separated)...',
    'email-mmos-textarea': locale === 'th'
      ? 'หรือแก้ไขรหัส MMO ในอีเมล (คั่นด้วยบรรทัดใหม่หรือจุลภาค)...'
      : 'Or Paste/Edit Email MMOs (newline or comma separated)...',
    'db-search-input': locale === 'th'
      ? 'ค้นหาด้วยรหัสพาร์ท (PN), MMO หรือรายละเอียดพาร์ท...'
      : 'Search by PN / MMO / Part Description...'
  };
  
  for (const [id, val] of Object.entries(textareas)) {
    const el = document.getElementById(id);
    if (el) el.placeholder = val;
  }
}

function setElementText(id, txt) {
  const el = document.getElementById(id);
  if (el) el.innerText = txt;
}

// Language Switch handler
function changeLanguage(lang) {
  locale = lang;
  
  const thBtn = document.getElementById('btn-lang-th');
  const enBtn = document.getElementById('btn-lang-en');
  
  if (lang === 'th') {
    thBtn.className = 'px-2 py-0.5 text-[10px] font-black rounded transition-all cursor-pointer bg-[#10B981] text-white';
    enBtn.className = 'px-2 py-0.5 text-[10px] font-black rounded transition-all cursor-pointer text-[#A6ADB5] hover:text-white bg-transparent';
  } else {
    enBtn.className = 'px-2 py-0.5 text-[10px] font-black rounded transition-all cursor-pointer bg-[#10B981] text-white';
    thBtn.className = 'px-2 py-0.5 text-[10px] font-black rounded transition-all cursor-pointer text-[#A6ADB5] hover:text-white bg-transparent';
  }
  
  updateUI();
  
  // If report slide data needs refreshing
  if (excelFiles.length > 0) {
    refreshReportFieldsDefault();
    renderAll();
  }
}

// Case Sensitivity Switch handler
function toggleCaseSensitivity() {
  caseSensitive = !caseSensitive;
  const dot = document.getElementById('case-dot');
  if (caseSensitive) {
    dot.className = 'w-2 h-2 rounded-full bg-[#10B981]';
  } else {
    dot.className = 'w-2 h-2 rounded-full bg-[#EF4444]';
  }
  
  renderAll();
}

// Toggle Customize Settings Panel
function toggleCustomizePanel() {
  showCustomizePanel = !showCustomizePanel;
  const panel = document.getElementById('customize-editor-block');
  const label = document.getElementById('txt-customize-collapse-state');
  
  if (showCustomizePanel) {
    panel.classList.remove('hidden');
    panel.classList.add('grid');
    label.innerText = locale === 'th' ? '[- คลิกเพื่อย่อแผงควบคุม]' : '[- Click to Collapse]';
  } else {
    panel.classList.add('hidden');
    panel.classList.remove('grid');
    label.innerText = locale === 'th' ? '[+ คลิกเพื่อปรับแต่งข้อความ]' : '[+ Click to Customize Texts]';
  }
}

// Tab switcher for status result logs vs corporate presentation slide
function setResultsViewTab(tab) {
  resultsViewTab = tab;
  
  const reportBtn = document.getElementById('tab-btn-report');
  const databaseBtn = document.getElementById('tab-btn-database');
  
  const reportView = document.getElementById('tab-view-report');
  const databaseView = document.getElementById('tab-view-database');
  
  if (tab === 'report') {
    reportBtn.className = 'flex items-center gap-1.5 px-3 py-1 rounded transition-colors bg-[#10B981] text-white';
    databaseBtn.className = 'flex items-center gap-1.5 px-3 py-1 rounded transition-colors text-[#A6ADB5] hover:text-white';
    reportView.classList.remove('hidden');
    databaseView.classList.add('hidden');
  } else {
    databaseBtn.className = 'flex items-center gap-1.5 px-3 py-1 rounded transition-colors bg-[#10B981] text-white';
    reportBtn.className = 'flex items-center gap-1.5 px-3 py-1 rounded transition-colors text-[#A6ADB5] hover:text-white';
    databaseView.classList.remove('hidden');
    reportView.classList.add('hidden');
  }
}

// 4. PARSERS & FILE HANDLERS
function initializeDragAndDrop() {
  // Excel File Input Drag and Drop
  const excelDrop = document.getElementById('excel-dropzone');
  const excelFileInp = document.getElementById('excel-file-input');
  
  excelDrop.addEventListener('click', () => excelFileInp.click());
  excelDrop.addEventListener('dragover', (e) => {
    e.preventDefault();
    excelDrop.className = 'h-20 border border-dashed border-[#1A1C1E] bg-[#EDEFF2] rounded flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors p-2';
  });
  excelDrop.addEventListener('dragleave', () => {
    excelDrop.className = 'h-20 border border-dashed border-[#D1D5DB] hover:border-[#9CA3AF] bg-[#F8F9FA] rounded flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors p-2';
  });
  excelDrop.addEventListener('drop', (e) => {
    e.preventDefault();
    excelDrop.className = 'h-20 border border-dashed border-[#D1D5DB] hover:border-[#9CA3AF] bg-[#F8F9FA] rounded flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors p-2';
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleExcelDroppedFiles(Array.from(e.dataTransfer.files));
    }
  });
  excelFileInp.addEventListener('change', (e) => {
    if (e.target.files && e.target.files.length > 0) {
      handleExcelDroppedFiles(Array.from(e.target.files));
      e.target.value = ''; // clear
    }
  });

  // Email File Input Drag and Drop
  const emailDrop = document.getElementById('email-dropzone');
  const emailFileInp = document.getElementById('email-file-input');
  
  emailDrop.addEventListener('click', () => emailFileInp.click());
  emailDrop.addEventListener('dragover', (e) => {
    e.preventDefault();
    emailDrop.className = 'h-24 border border-dashed border-[#1A1C1E] bg-[#EDEFF2] rounded flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors p-2';
  });
  emailDrop.addEventListener('dragleave', () => {
    emailDrop.className = 'h-24 border border-dashed border-[#D1D5DB] hover:border-[#9CA3AF] bg-[#F8F9FA] rounded flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors p-2';
  });
  emailDrop.addEventListener('drop', (e) => {
    e.preventDefault();
    emailDrop.className = 'h-24 border border-dashed border-[#D1D5DB] hover:border-[#9CA3AF] bg-[#F8F9FA] rounded flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors p-2';
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleEmailDroppedFiles(Array.from(e.dataTransfer.files));
    }
  });
  emailFileInp.addEventListener('change', (e) => {
    if (e.target.files && e.target.files.length > 0) {
      handleEmailDroppedFiles(Array.from(e.target.files));
      e.target.value = ''; // clear
    }
  });
}

function initializeTextareaTriggers() {
  const pasteTxt = document.getElementById('excel-paste-textarea');
  const parseBtn = document.getElementById('btn-parse-excel');
  
  pasteTxt.addEventListener('input', () => {
    if (pasteTxt.value.trim().length > 0) {
      parseBtn.classList.remove('hidden');
    } else {
      parseBtn.classList.add('hidden');
    }
  });
}

// Robust Float parser
function parseShortQty(val) {
  if (val === undefined || val === null) return 0;
  if (typeof val === 'number') return val;
  let str = String(val).trim();
  if (!str) return 0;
  
  let isNegative = false;
  if (str.startsWith('(') && str.endsWith(')')) {
    isNegative = true;
    str = str.slice(1, -1);
  }
  
  str = str.replace(/,/g, '').replace(/\s/g, '');
  if (str.startsWith('-')) {
    isNegative = true;
    str = str.slice(1);
  }
  
  let num = parseFloat(str);
  if (isNaN(num)) return 0;
  return isNegative ? -Math.abs(num) : num;
}

// Decode Thai ANSI (Windows-874) if UTF-8 fails
function decodeText(arrayBuffer) {
  const utf8Decoder = new TextDecoder('utf-8', { fatal: true });
  try {
    return utf8Decoder.decode(arrayBuffer);
  } catch (err) {
    try {
      const thaiDecoder = new TextDecoder('windows-874');
      return thaiDecoder.decode(arrayBuffer);
    } catch (e) {
      const fallbackDecoder = new TextDecoder('utf-8', { fatal: false });
      return fallbackDecoder.decode(arrayBuffer);
    }
  }
}

// Delimited Text / CSV Row Parser
function parseCsvText(text) {
  if (!text) return [];
  const lines = text.split(/\r?\n/).map(line => line.trim()).filter(line => line.length > 0);
  let delimiter = ',';
  if (lines.length > 0) {
    const firstLine = lines[0];
    const commas = (firstLine.match(/,/g) || []).length;
    const semicolons = (firstLine.match(/;/g) || []).length;
    const tabs = (firstLine.match(/\t/g) || []).length;
    
    if (semicolons > commas && semicolons > tabs) delimiter = ';';
    else if (tabs > commas && tabs > semicolons) delimiter = '\t';
  }

  const result = [];
  for (const line of lines) {
    const row = [];
    let insideQuote = false;
    let currentCell = '';
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      const nextChar = line[i + 1];
      
      if (char === '"') {
        if (insideQuote && nextChar === '"') {
          currentCell += '"';
          i++;
        } else {
          insideQuote = !insideQuote;
        }
      } else if (char === delimiter && !insideQuote) {
        row.push(currentCell.trim());
        currentCell = '';
      } else {
        currentCell += char;
      }
    }
    row.push(currentCell.trim());
    result.push(row);
  }
  return result;
}

// Score-based column detector and rows mapper
function parseRowsFromSheet(data, pnIdx, qtyIdx, mmoIdx, nameIdx, startRowIdx, filename) {
  const parsed = [];
  const filenameMmo = filename ? filename.replace(/\.[^/.]+$/, "").trim() : '';

  for (let r = startRowIdx; r < data.length; r++) {
    const row = data[r];
    if (!row || row.length === 0) continue;

    const pnRaw = row[pnIdx];
    const pn = pnRaw !== undefined && pnRaw !== null ? String(pnRaw).trim() : '';
    const rawQty = row[qtyIdx];
    const shortQty = parseShortQty(rawQty);
    const mmoRaw = row[mmoIdx];
    let mmo = mmoRaw !== undefined && mmoRaw !== null ? String(mmoRaw).trim() : '';
    
    const partNameRaw = nameIdx >= 0 ? row[nameIdx] : undefined;
    const partName = partNameRaw !== undefined && partNameRaw !== null ? String(partNameRaw).trim() : '';

    if (filenameMmo) {
      mmo = filenameMmo;
    }

    if (pn) {
      parsed.push({
        id: 'row-' + Math.random().toString(36).substring(2, 9),
        PN: pn,
        ShortQty: shortQty,
        MMO: mmo,
        PartName: partName,
      });
    }
  }
  return parsed;
}

// Paste Excel handler
function parseExcelPastedRows() {
  const pasteTxt = document.getElementById('excel-paste-textarea');
  const text = pasteTxt.value;
  if (!text.trim()) return;

  const lines = text.split(/\r?\n/);
  const parsedRows = [];
  let skipFirstLine = false;

  if (lines.length > 0) {
    const firstLineLower = lines[0].toLowerCase();
    if (
      firstLineLower.includes('pn') ||
      firstLineLower.includes('part') ||
      firstLineLower.includes('qty') ||
      firstLineLower.includes('mmo') ||
      firstLineLower.includes('short') ||
      firstLineLower.includes('name') ||
      firstLineLower.includes('desc')
    ) {
      skipFirstLine = true;
    }
  }

  const virtualFileName = `Pasted_Shortages_${excelFiles.length + 1}.csv`;
  const filenameMmo = virtualFileName.replace(/\.[^/.]+$/, "").trim();

  lines.forEach((line, index) => {
    if (index === 0 && skipFirstLine) return;
    if (!line.trim()) return;

    const delimiter = line.includes('\t') ? '\t' : (line.includes(';') ? ';' : ',');
    const cols = line.split(delimiter).map(col => col.trim());

    if (cols.length >= 2) {
      const pn = cols[0];
      let shortQty = 0;
      let mmo = '';
      let partName = '';

      if (cols.length === 2) {
        const cleanValStr = cols[1].replace(/,/g, '').trim();
        const isNum = !isNaN(Number(cleanValStr)) && cleanValStr !== '';
        if (isNum) {
          shortQty = parseShortQty(cols[1]);
        } else {
          mmo = cols[1];
        }
      } else if (cols.length === 3) {
        const isCol1Num = !isNaN(Number(cols[1].replace(/,/g, '').trim()));
        const isCol2Num = !isNaN(Number(cols[2].replace(/,/g, '').trim()));
        
        if (isCol1Num) {
          shortQty = parseShortQty(cols[1]);
          const val = cols[2] || '';
          if (val.toUpperCase().startsWith('MMO') || val.toUpperCase().startsWith('WO') || val.toUpperCase().startsWith('MO')) {
            mmo = val;
          } else {
            partName = val;
          }
        } else if (isCol2Num) {
          partName = cols[1];
          shortQty = parseShortQty(cols[2]);
        } else {
          shortQty = parseShortQty(cols[1]);
          mmo = cols[2];
        }
      } else if (cols.length >= 4) {
        let qtyColIdx = 2;
        for (let i = 1; i < cols.length; i++) {
          const isNum = !isNaN(Number(cols[i].replace(/,/g, '').trim()));
          if (isNum && cols[i].trim() !== '') {
            qtyColIdx = i;
            break;
          }
        }
        
        shortQty = parseShortQty(cols[qtyColIdx]);
        
        if (qtyColIdx === 1) {
          mmo = cols[2] || '';
          partName = cols.slice(3).join(', ');
        } else if (qtyColIdx === 2) {
          partName = cols[1];
          mmo = cols[3] || '';
        } else {
          partName = cols[1];
          mmo = cols[2] || '';
        }
      }

      if (filenameMmo) mmo = filenameMmo;

      if (pn) {
        parsedRows.push({
          id: 'row-' + Math.random().toString(36).substring(2, 9),
          PN: pn,
          ShortQty: shortQty,
          MMO: mmo,
          PartName: partName,
        });
      }
    }
  });

  if (parsedRows.length > 0) {
    const newFileId = 'file-' + Math.random().toString(36).substring(2, 9);
    const newFile = {
      id: newFileId,
      name: virtualFileName,
      rows: parsedRows,
      pnColIndex: 0,
      qtyColIndex: 1,
      mmoColIndex: 2,
      nameColIndex: -1,
    };

    excelFiles.push(newFile);
    activeExcelFileId = newFileId;
    pasteTxt.value = '';
    document.getElementById('btn-parse-excel').classList.add('hidden');
    hideExcelError();
    
    refreshReportFieldsDefault();
    renderAll();
  } else {
    showExcelError('Could not parse any valid rows. Please check your data format.');
  }
}

// Excel Upload Handler (SheetJS)
function handleExcelDroppedFiles(files) {
  files.forEach((file) => {
    const fileExtension = file.name.split('.').pop().toLowerCase();
    const isExcel = fileExtension === 'xlsx' || fileExtension === 'xls';
    const isCsv = fileExtension === 'csv' || fileExtension === 'txt';
    
    if (isExcel || isCsv) {
      const reader = new FileReader();
      const newFileId = 'file-' + Math.random().toString(36).substring(2, 9);
      
      reader.onload = (e) => {
        try {
          let jsonData = [];
          
          if (isExcel) {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            if (workbook.SheetNames.length === 0) {
              showExcelError(`The file ${file.name} has no worksheets.`);
              return;
            }
            const firstSheet = workbook.SheetNames[0];
            jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet], { header: 1 });
          } else {
            const buffer = e.target.result;
            const text = decodeText(buffer);
            jsonData = parseCsvText(text);
          }
          
          if (jsonData.length === 0) {
            showExcelError(`The file ${file.name} is empty.`);
            return;
          }

          // Column detection score metrics
          const maxCols = Math.max(...jsonData.map(r => r ? r.length : 0));
          let bestHeaderRowIndex = 0;
          let maxHeaderMatches = -1;

          for (let r = 0; r < Math.min(jsonData.length, 10); r++) {
            const row = jsonData[r];
            if (!row || row.length === 0) continue;
            let rowMatches = 0;
            row.forEach((cell) => {
              if (cell !== undefined && cell !== null) {
                const cellStr = String(cell).toLowerCase().trim();
                const isPn = cellStr.includes('pn') || cellStr.includes('part') || cellStr.includes('p/n') || cellStr.includes('material') || cellStr.includes('item') || cellStr.includes('รหัส') || cellStr.includes('พาร์ท');
                const isQty = cellStr.includes('qty') || cellStr.includes('short') || cellStr.includes('quantity') || cellStr.includes('shortage') || cellStr.includes('จำนวน') || cellStr.includes('ยอด') || cellStr.includes('ขาด');
                const isMmo = cellStr === 'wo' || cellStr === 'mo' || cellStr === 'w/o' || cellStr === 'm.o' || cellStr.includes('mmo') || cellStr.includes('work order') || cellStr.includes('work_order') || cellStr.includes('order no') || cellStr.includes('ใบสั่ง') || cellStr.includes('สั่งผลิต');
                if (isPn || isQty || isMmo) rowMatches++;
              }
            });
            if (rowMatches > maxHeaderMatches) {
              maxHeaderMatches = rowMatches;
              bestHeaderRowIndex = r;
            }
          }

          const headerRow = jsonData[bestHeaderRowIndex] || [];
          let pnIdx = 0;
          let qtyIdx = 1;
          let mmoIdx = 2;
          let nameIdx = -1;

          let maxPnScore = -1;
          let maxQtyScore = -1;
          let maxMmoScore = -1;
          let maxNameScore = -1;

          const lowerEmailMmos = new Set((emailData.mmos || []).map(m => m.trim().toLowerCase()));

          for (let col = 0; col < maxCols; col++) {
            let pnScore = 0;
            let qtyScore = 0;
            let mmoScore = 0;
            let nameScore = 0;

            const headerCell = headerRow[col];
            if (headerCell !== undefined && headerCell !== null) {
              const headerStr = String(headerCell).toLowerCase().trim();

              if (headerStr.includes('pn') || headerStr.includes('part') || headerStr.includes('p/n') || headerStr.includes('material') || headerStr.includes('item') || headerStr.includes('รหัส') || headerStr.includes('พาร์ท') || headerStr.includes('ชิ้นส่วน')) {
                pnScore += 100;
              }
              if (headerStr.includes('qty') || headerStr.includes('short') || headerStr.includes('quantity') || headerStr.includes('shortage') || headerStr.includes('จำนวน') || headerStr.includes('ยอด') || headerStr.includes('ขาด')) {
                qtyScore += 100;
              }
              if (headerStr === 'wo' || headerStr === 'mo' || headerStr === 'w/o' || headerStr === 'm.o' || headerStr.includes('w.o') || headerStr.includes('m.o') || headerStr.includes('wo') || headerStr.includes('mmo') || headerStr.includes('work order') || headerStr.includes('work_order') || headerStr.includes('order no') || headerStr.includes('ใบสั่ง') || headerStr.includes('สั่งผลิต')) {
                mmoScore += 100;
              }
              if (headerStr.includes('name') || headerStr.includes('desc') || headerStr.includes('detail') || headerStr.includes('ชื่อ') || headerStr.includes('รายละเอียด') || headerStr.includes('นิยาม')) {
                nameScore += 100;
              }
              if (headerStr.includes('remark') || headerStr.includes('line') || headerStr.includes('status') || headerStr.includes('หมายเหตุ') || headerStr.includes('สถานะ') || headerStr.includes('คอมเมนต์') || headerStr.includes('comment')) {
                mmoScore -= 150;
              }
            }

            for (let r = bestHeaderRowIndex + 1; r < Math.min(jsonData.length, bestHeaderRowIndex + 30); r++) {
              const row = jsonData[r];
              if (!row) continue;
              const cellVal = row[col];
              if (cellVal === undefined || cellVal === null) continue;

              const valStr = String(cellVal).trim();
              if (!valStr) continue;

              const lowerVal = valStr.toLowerCase();
              const isPnPattern = /^[a-zA-Z0-9-]{8,25}$/.test(valStr);
              const isPureNumber = /^\d+$/.test(valStr);
              if (isPnPattern && !isPureNumber) pnScore += 5;

              const cleanVal = valStr.replace(/,/g, '').replace(/\s/g, '');
              const parsedNum = parseFloat(cleanVal.startsWith('(') && cleanVal.endsWith(')') ? cleanVal.slice(1, -1) : cleanVal);
              if (!isNaN(parsedNum) && cleanVal.length < 8) qtyScore += 5;

              if (lowerVal.startsWith('mmo')) mmoScore += 15;
              if (lowerEmailMmos.has(lowerVal)) mmoScore += 50;

              if (valStr.includes(' ') && valStr.length > 10 && isNaN(Number(valStr))) nameScore += 5;
            }

            if (pnScore > maxPnScore) {
              maxPnScore = pnScore;
              pnIdx = col;
            }
            if (qtyScore > maxQtyScore) {
              maxQtyScore = qtyScore;
              qtyIdx = col;
            }
            if (mmoScore > maxMmoScore) {
              maxMmoScore = mmoScore;
              mmoIdx = col;
            }
            if (nameScore > maxNameScore) {
              maxNameScore = nameScore;
              nameIdx = col;
            }
          }

          const fullHeaders = [];
          for (let i = 0; i < maxCols; i++) {
            const cellVal = headerRow[i];
            const name = cellVal !== undefined && cellVal !== null ? String(cellVal).trim() : '';
            // Standard excel column encoder (A, B, C...)
            const colLetter = String.fromCharCode(65 + i);
            fullHeaders.push(name ? `${name} (Col ${colLetter})` : `Column ${colLetter}`);
          }

          const parsed = parseRowsFromSheet(jsonData, pnIdx, qtyIdx, mmoIdx, nameIdx, bestHeaderRowIndex + 1, file.name);

          // Save spreadsheets data
          excelSheets[newFileId] = { data: jsonData, headers: fullHeaders };

          const newFile = {
            id: newFileId,
            name: file.name,
            rows: parsed,
            pnColIndex: pnIdx,
            qtyColIndex: qtyIdx,
            mmoColIndex: mmoIdx,
            nameColIndex: nameIdx,
          };

          excelFiles.push(newFile);
          activeExcelFileId = newFileId;
          hideExcelError();
          
          refreshReportFieldsDefault();
          renderAll();
        } catch (err) {
          showExcelError(`Failed to parse ${file.name}: ${err.message}`);
        }
      };
      
      if (isExcel) {
        reader.readAsArrayBuffer(file);
      } else {
        reader.readAsArrayBuffer(file); // standard text CSV
      }
    } else {
      showExcelError(`Unsupported file format: ${file.name}`);
    }
  });
}

function showExcelError(msg) {
  const banner = document.getElementById('excel-error-banner');
  const message = document.getElementById('excel-error-message');
  message.innerText = msg;
  banner.classList.remove('hidden');
}

function hideExcelError() {
  document.getElementById('excel-error-banner').classList.add('hidden');
}

// Email file parser (Handles outlook MSG file via CDN MsgReader, or fallbacks)
async function handleEmailDroppedFiles(files) {
  hideEmailError();
  for (const file of files) {
    const fileExtension = file.name.split('.').pop().toLowerCase();
    
    if (fileExtension === 'msg') {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const buffer = e.target.result;
          
          // Instantiate MsgReader
          let ReaderConstructor = window.MsgReader;
          if (ReaderConstructor && ReaderConstructor.default) {
            ReaderConstructor = ReaderConstructor.default;
          }
          
          if (!ReaderConstructor) {
            throw new Error("MsgReader library not loaded via CDN. Fallback text extraction.");
          }
          
          const msgReader = new ReaderConstructor(buffer);
          const fileData = msgReader.getFileData();
          
          const subject = fileData.subject || '';
          let bodyText = fileData.body || '';
          if (!bodyText && fileData.html) {
            bodyText = fileData.html
              .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
              .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
              .replace(/<[^>]+>/g, '\n');
          }
          
          const combinedText = `${subject}\n${bodyText}`;
          const extracted = extractDataFromEmailText(combinedText);
          
          addEmailSource(file.name, extracted);
        } catch (err) {
          // Fallback simple binary text reader in case MsgReader fails
          const textReader = new FileReader();
          textReader.onload = () => {
            const ext = extractDataFromEmailText(textReader.result);
            addEmailSource(file.name, ext);
          };
          textReader.readAsText(file);
        }
      };
      reader.readAsArrayBuffer(file);
    } else {
      // EML / HTML / Plain Text
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const buffer = e.target.result;
          const bytes = new Uint8Array(buffer);
          let decodedText = '';
          
          try {
            const decoderUtf8 = new TextDecoder('utf-8', { fatal: true });
            decodedText = decoderUtf8.decode(bytes);
          } catch (err) {
            const decoderLatin1 = new TextDecoder('windows-1252');
            decodedText = decoderLatin1.decode(bytes);
          }

          if (decodedText.toLowerCase().includes('<html') || /<[a-z][\s\S]*>/i.test(decodedText)) {
            decodedText = decodedText
              .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
              .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
              .replace(/<[^>]+>/g, '\n');
          }

          const extracted = extractDataFromEmailText(decodedText);
          addEmailSource(file.name, extracted);
        } catch (err) {
          showEmailError(`Failed to read file "${file.name}": ${err.message}`);
        }
      };
      reader.readAsArrayBuffer(file);
    }
  }
}

// Regex matching MMO and PNs inside Email
function extractDataFromEmailText(text) {
  const mmoRegex = /\b(?:MMO[A-Za-z0-9]?|WO|MO)[-_\s]?[A-Za-z0-9-]{4,15}\b/gi;
  const pnRegex = /\b[0-9A-Za-z][A-Za-z0-9-]{8,24}\b/gi;

  const lines = text.split(/\r?\n/);
  const pns = [];
  const mmos = [];
  const pnToMmoMap = {};

  let currentMmo = '';

  lines.forEach(line => {
    const lineMmos = line.match(mmoRegex);
    if (lineMmos && lineMmos.length > 0) {
      currentMmo = lineMmos[lineMmos.length - 1].trim().toUpperCase();
      lineMmos.forEach(m => mmos.push(m.trim().toUpperCase()));
    }

    const linePns = line.match(pnRegex);
    if (linePns) {
      linePns.forEach(p => {
        const cleanPn = p.trim();
        const upperPn = cleanPn.toUpperCase();
        
        const isMmoCode = /\b(?:MMO[A-Za-z0-9]?|WO|MO)[-_\s]?[A-Za-z0-9-]{4,15}\b/i.test(cleanPn) || 
                          upperPn.startsWith('MMO') || upperPn.startsWith('WO') || upperPn.startsWith('MO');
        const hasDigit = /\d/.test(cleanPn);
        
        if (!isMmoCode && hasDigit) {
          pns.push(cleanPn);
          if (currentMmo) {
            pnToMmoMap[cleanPn.toLowerCase()] = currentMmo;
          }
        }
      });
    }
  });

  return {
    pns: Array.from(new Set(pns)),
    mmos: Array.from(new Set(mmos)),
    pnToMmoMap
  };
}

// Track uploaded files to handle Union merges
let uploadedEmailFiles = [];

function addEmailSource(filename, data) {
  const newId = 'email-' + Math.random().toString(36).substring(2, 9);
  uploadedEmailFiles.push({
    id: newId,
    name: filename,
    pns: data.pns,
    mmos: data.mmos,
    pnToMmoMap: data.pnToMmoMap
  });

  recalculateMergedEmailData();
  hideEmailError();
}

function recalculateMergedEmailData() {
  if (uploadedEmailFiles.length === 0) {
    emailData = { pns: [], mmos: [], rawPns: '', rawMmos: '', pnToMmoMap: {} };
  } else {
    const allPns = Array.from(new Set(uploadedEmailFiles.flatMap(f => f.pns)));
    const allMmos = Array.from(new Set(uploadedEmailFiles.flatMap(f => f.mmos)));
    
    const mergedMap = {};
    uploadedEmailFiles.forEach(f => {
      if (f.pnToMmoMap) Object.assign(mergedMap, f.pnToMmoMap);
    });

    emailData = {
      pns: allPns,
      mmos: allMmos,
      rawPns: allPns.join('\n'),
      rawMmos: allMmos.join(', '),
      pnToMmoMap: mergedMap
    };
  }

  // Update textareas
  document.getElementById('email-pns-textarea').value = emailData.rawPns;
  document.getElementById('email-mmos-textarea').value = emailData.rawMmos;

  refreshReportFieldsDefault();
  renderAll();
}

function removeEmailFile(id, e) {
  if (e) e.stopPropagation();
  uploadedEmailFiles = uploadedEmailFiles.filter(f => f.id !== id);
  recalculateMergedEmailData();
}

function clearEmailData() {
  uploadedEmailFiles = [];
  recalculateMergedEmailData();
}

function showEmailError(msg) {
  const banner = document.getElementById('email-error-banner');
  const message = document.getElementById('email-error-message');
  message.innerText = msg;
  banner.classList.remove('hidden');
}

function hideEmailError() {
  document.getElementById('email-error-banner').classList.add('hidden');
}

// Handles user-typed edits in Email textareas
function onEmailPnsTextareaChange() {
  const val = document.getElementById('email-pns-textarea').value;
  const list = val.split(/[\n,;\t]+/).map(i => i.trim()).filter(i => i.length > 0);
  
  // Parse MMOs too if they pasted complete blocks
  const hasMmoPatterns = /\b(?:MMO[A-Za-z0-9]?|WO|MO)[-_\s]?[A-Za-z0-9-]{4,15}\b/i.test(val);
  if (hasMmoPatterns) {
    const ext = extractDataFromEmailText(val);
    if (ext.pns.length > 0 || ext.mmos.length > 0) {
      emailData = {
        pns: ext.pns,
        mmos: ext.mmos,
        rawPns: ext.pns.join('\n'),
        rawMmos: ext.mmos.join(', '),
        pnToMmoMap: ext.pnToMmoMap
      };
      document.getElementById('email-pns-textarea').value = emailData.rawPns;
      document.getElementById('email-mmos-textarea').value = emailData.rawMmos;
      
      refreshReportFieldsDefault();
      renderAll();
      return;
    }
  }

  emailData.pns = list;
  emailData.rawPns = val;
  
  // Clear obsolete mapping keys
  const cleanedMap = {};
  list.forEach(pn => {
    const norm = pn.toLowerCase();
    if (emailData.pnToMmoMap[norm]) {
      cleanedMap[norm] = emailData.pnToMmoMap[norm];
    }
  });
  emailData.pnToMmoMap = cleanedMap;

  refreshReportFieldsDefault();
  renderAll();
}

function onEmailMmosTextareaChange() {
  const val = document.getElementById('email-mmos-textarea').value;
  const list = val.split(/[\n,;\t]+/).map(i => i.trim()).filter(i => i.length > 0);

  const hasPnPatterns = /\b[0-9A-Za-z][A-Za-z0-9-]{8,24}\b/i.test(val);
  if (hasPnPatterns) {
    const ext = extractDataFromEmailText(val);
    if (ext.pns.length > 0 || ext.mmos.length > 0) {
      emailData = {
        pns: ext.pns,
        mmos: ext.mmos,
        rawPns: ext.pns.join('\n'),
        rawMmos: ext.mmos.join(', '),
        pnToMmoMap: ext.pnToMmoMap
      };
      document.getElementById('email-pns-textarea').value = emailData.rawPns;
      document.getElementById('email-mmos-textarea').value = emailData.rawMmos;
      
      refreshReportFieldsDefault();
      renderAll();
      return;
    }
  }

  emailData.mmos = list;
  emailData.rawMmos = val;
  
  // Clear maps whose MMO codes are deleted
  const allowed = new Set(list.map(m => m.toUpperCase()));
  const cleanedMap = {};
  Object.entries(emailData.pnToMmoMap).forEach(([pn, mmo]) => {
    if (allowed.has(mmo.toUpperCase())) {
      cleanedMap[pn] = mmo;
    }
  });
  emailData.pnToMmoMap = cleanedMap;

  refreshReportFieldsDefault();
  renderAll();
}

// 5. CORE COMPARATIVE MATCHING ENGINE
function computeReconciliationResults() {
  const emailMmoSet = new Set(
    emailData.mmos.map(m => caseSensitive ? m.trim() : m.trim().toLowerCase())
  );
  const emailPnSet = new Set(
    emailData.pns.map(p => caseSensitive ? p.trim() : p.trim().toLowerCase())
  );

  if (excelFiles.length === 0) return [];

  const seenEmailPnsInExcel = new Set();
  const excelResults = [];
  const excelMmosSet = new Set();

  excelFiles.forEach((file) => {
    const fileMmoCandidate = file.name.replace(/\.[^/.]+$/, "").trim();
    const targetNormalized = caseSensitive ? fileMmoCandidate : fileMmoCandidate.toLowerCase();
    
    const hasExactMatch = emailData.mmos.some((mmo) => {
      const cleanMmo = caseSensitive ? mmo.trim() : mmo.trim().toLowerCase();
      return cleanMmo === targetNormalized;
    });

    let extractedMmo = null;
    let isExtractedMmoInEmail = false;

    if (hasExactMatch) {
      extractedMmo = fileMmoCandidate;
      isExtractedMmoInEmail = true;
    } else {
      const matchedMmo = emailData.mmos.find((mmo) => {
        const cleanMmo = mmo.trim().toLowerCase().replace(/\s/g, '');
        const cleanFn = file.name.toLowerCase().replace(/\s/g, '');
        const cleanFnNoExt = fileMmoCandidate.toLowerCase().replace(/\s/g, '');
        return cleanFn.includes(cleanMmo) || cleanMmo.includes(cleanFnNoExt);
      });

      if (matchedMmo) {
        extractedMmo = matchedMmo.trim();
        isExtractedMmoInEmail = true;
      } else {
        extractedMmo = fileMmoCandidate;
        isExtractedMmoInEmail = false;
      }
    }

    file.rows.forEach((row) => {
      const cleanedPN = row.PN.trim();
      const resolvedMMO = extractedMmo ? extractedMmo : row.MMO.trim();

      const targetMmo = caseSensitive ? resolvedMMO : resolvedMMO.toLowerCase();
      const targetPn = caseSensitive ? cleanedPN : cleanedPN.toLowerCase();

      const mmoInEmail = emailMmoSet.has(targetMmo);
      const m = emailPnSet.has(targetPn);
      if (m) seenEmailPnsInExcel.add(targetPn);

      const isShort = row.ShortQty > 0;
      const isNeedToCheck = m && isShort;

      const status = isNeedToCheck ? '1st' : 'Good';
      excelMmosSet.add(targetMmo);

      excelResults.push({
        id: `${file.id}-${row.id}`,
        PN: row.PN,
        MMO: resolvedMMO,
        ShortQty: row.ShortQty,
        PartName: row.PartName,
        e: isShort,
        m,
        mmoInEmail,
        status,
      });
    });
  });

  // Calculate Discrepancy Level 2nd Status rows (PN reported in email but not in Excel file)
  const emailDiscrepancyResults = [];
  const emailPnOriginalMap = new Map();
  emailData.pns.forEach(p => {
    emailPnOriginalMap.set(caseSensitive ? p.trim() : p.trim().toLowerCase(), p.trim());
  });

  emailPnSet.forEach((targetPn) => {
    if (!seenEmailPnsInExcel.has(targetPn)) {
      const originalPn = emailPnOriginalMap.get(targetPn) || targetPn;
      const mappedMmo = emailData.pnToMmoMap[targetPn.toLowerCase()];
      
      if (mappedMmo) {
        const normMappedMmo = caseSensitive ? mappedMmo.trim() : mappedMmo.trim().toLowerCase();
        if (!excelMmosSet.has(normMappedMmo)) {
          // Belongs to an MMO currently not active in Excel sheets. Skip!
          return;
        }
      } else if (emailData.mmos.length > 1) {
        // Multi-MMO mail without explicit maps. Skip to prevent noisy logs!
        return;
      }

      const resolvedMmoForDiscrepancy = mappedMmo 
        ? (caseSensitive ? mappedMmo : mappedMmo.toUpperCase()) 
        : 'Unknown MMO';

      emailDiscrepancyResults.push({
        id: `email-discrepancy-${targetPn}`,
        PN: originalPn,
        MMO: resolvedMmoForDiscrepancy,
        ShortQty: 0,
        PartName: locale === 'th' ? '[พบพาร์ทในอีเมลแต่ไม่อยู่ในไฟล์ Excel]' : '[PN in Email but not in Excel]',
        e: false,
        m: true,
        mmoInEmail: true,
        status: '2nd',
      });
    }
  });

  const finalResults = [...excelResults, ...emailDiscrepancyResults];

  // Sorting: 1st > 2nd > Good (Good/Not reported)
  const statusOrder = { '1st': 1, '2nd': 2, 'Good': 3, 'Not reported': 3 };
  finalResults.sort((a, b) => {
    const oA = statusOrder[a.status] || 99;
    const oB = statusOrder[b.status] || 99;
    if (oA !== oB) return oA - oB;
    return a.PN.localeCompare(b.PN, undefined, { numeric: true, sensitivity: 'base' });
  });

  return finalResults;
}

// Stats metrics
function calculateStats(results) {
  let total = results.length;
  let notReported = 0;
  let first = 0;
  let second = 0;
  let good = 0;

  results.forEach(r => {
    if (r.status === 'Not reported') notReported++;
    else if (r.status === '1st') first++;
    else if (r.status === '2nd') second++;
    else if (r.status === 'Good') good++;
  });

  return { total, notReported, first, second, good };
}

// Group results by MMO for paginated slide previews
function getResultsGroupedByMmo(results) {
  const groups = {};
  results.forEach(row => {
    const mmo = row.MMO || 'Unknown MMO';
    if (!groups[mmo]) {
      groups[mmo] = {
        mmo,
        first: 0,
        second: 0,
        good: 0,
        notReported: 0,
        total: 0,
        pns: []
      };
    }
    if (row.status === '1st') groups[mmo].first++;
    else if (row.status === '2nd') groups[mmo].second++;
    else if (row.status === 'Good') groups[mmo].good++;
    else if (row.status === 'Not reported') groups[mmo].notReported++;
    
    groups[mmo].total++;
    groups[mmo].pns.push(row);
  });
  return Object.values(groups);
}

// 6. RENDER MASTER ROUTINE
function renderAll() {
  const results = computeReconciliationResults();
  
  // Update Excel Panel Elements
  renderExcelFilesList();
  renderActiveExcelTable();
  
  // Update Email Panel Elements
  renderEmailOutputs();
  
  // Update Results Display Panel Elements
  renderResultsPanel(results);
}

// Render Excel List
function renderExcelFilesList() {
  const container = document.getElementById('excel-files-container');
  const list = document.getElementById('excel-files-list');
  const countSpan = document.getElementById('excel-files-count');
  
  if (excelFiles.length === 0) {
    container.classList.add('hidden');
    return;
  }
  
  container.classList.remove('hidden');
  countSpan.innerText = excelFiles.length;
  list.innerHTML = '';
  
  excelFiles.forEach((file) => {
    const isActive = file.id === activeExcelFileId;
    const cleanFilenameMmo = file.name.replace(/\.[^/.]+$/, "").trim();
    
    const card = document.createElement('div');
    card.onclick = () => {
      activeExcelFileId = file.id;
      renderAll();
    };
    
    card.className = `p-2 rounded border transition-all cursor-pointer flex flex-col justify-between gap-1 relative ${
      isActive
        ? 'border-[#1A1C1E] bg-[#EDEFF2] shadow-sm'
        : 'border-[#E5E7EB] bg-white hover:bg-zinc-50'
    }`;
    
    card.innerHTML = `
      <div class="flex items-start justify-between gap-2">
        <div class="flex items-center gap-1.5 overflow-hidden">
          <i data-lucide="file-spreadsheet" class="h-3.5 w-3.5 shrink-0 ${isActive ? 'text-zinc-800' : 'text-zinc-400'}"></i>
          <span class="text-[11px] font-bold text-zinc-800 truncate block" title="${file.name}">
            ${file.name}
          </span>
        </div>
        <button onclick="deleteExcelFile('${file.id}', event)" class="p-1 hover:bg-zinc-100 rounded text-zinc-400 hover:text-rose-600 transition-colors cursor-pointer shrink-0">
          <i data-lucide="trash-2" class="h-3 w-3"></i>
        </button>
      </div>

      <div class="flex flex-wrap items-center justify-between gap-1.5 pt-1 border-t border-zinc-100/60">
        <span class="text-[9px] font-mono text-zinc-500 font-medium">
          ${file.rows.length} ${translations.rows[locale]}
        </span>
        
        <span class="text-[9px] bg-emerald-50 text-emerald-700 border border-emerald-200 px-1.5 py-0.5 rounded font-mono font-bold flex items-center gap-1 shadow-sm">
          <i data-lucide="check" class="h-2.5 w-2.5 text-emerald-600"></i> ${translations.active[locale]}: ${cleanFilenameMmo}
        </span>
      </div>
    `;
    
    list.appendChild(card);
  });
  
  lucide.createIcons();
}

// Render active spreadsheet mapping and inputs
function renderActiveExcelTable() {
  const activeFile = excelFiles.find(f => f.id === activeExcelFileId);
  const emptyPlaceholder = document.getElementById('excel-empty-placeholder');
  const editorBlock = document.getElementById('excel-active-editor-block');
  
  if (!activeFile) {
    emptyPlaceholder.classList.remove('hidden');
    editorBlock.classList.add('hidden');
    return;
  }
  
  emptyPlaceholder.classList.add('hidden');
  editorBlock.classList.remove('hidden');
  
  // Fill header details
  document.getElementById('excel-active-filename').innerText = activeFile.name;
  document.getElementById('excel-active-rows-count').innerText = activeFile.rows.length;
  
  // Check column mapping configuration availability
  const mappingBlock = document.getElementById('excel-column-mapping-block');
  const sheetData = excelSheets[activeFile.id];
  
  if (sheetData && sheetData.headers.length > 0) {
    mappingBlock.classList.remove('hidden');
    
    populateMappingSelect('map-select-pn', sheetData.headers, activeFile.pnColIndex);
    populateMappingSelect('map-select-desc', sheetData.headers, activeFile.nameColIndex, true);
    populateMappingSelect('map-select-qty', sheetData.headers, activeFile.qtyColIndex);
    populateMappingSelect('map-select-mmo', sheetData.headers, activeFile.mmoColIndex);
  } else {
    mappingBlock.classList.add('hidden');
  }
  
  // Fill rows table
  const tbody = document.getElementById('excel-rows-table-body');
  tbody.innerHTML = '';
  
  if (activeFile.rows.length === 0) {
    tbody.innerHTML = `
      <div class="py-8 text-center text-[11px] text-[#9CA3AF] flex flex-col items-center justify-center gap-1">
        <i data-lucide="file-spreadsheet" class="h-6 w-6 text-[#9CA3AF]"></i>
        <p class="font-bold text-[#4B5563] uppercase text-[10px] tracking-wider">${locale === 'th' ? 'ไม่มีแถวในไฟล์นี้' : 'No rows in this file'}</p>
        <p class="text-[9px]">${locale === 'th' ? 'คลิก "เพิ่มแถว" ด้านบนเพื่อเพิ่มข้อมูลด้วยตนเอง' : 'Click "Add Row" above to insert data manually.'}</p>
      </div>
    `;
    lucide.createIcons();
    return;
  }
  
  activeFile.rows.forEach((row) => {
    const tr = document.createElement('div');
    tr.className = 'grid grid-cols-[1.2fr_1.5fr_0.8fr_1.2fr_30px] gap-2 px-2.5 py-1 items-center hover:bg-[#F8F9FA] transition-colors';
    
    tr.innerHTML = `
      <div>
        <input type="text" value="${row.PN}" oninput="updateSpreadsheetRowCell('${row.id}', 'PN', this.value)" placeholder="e.g. 73DIFF..." class="spreadsheet-input font-mono text-[#1F2937]">
      </div>
      <div>
        <input type="text" value="${row.PartName || ''}" oninput="updateSpreadsheetRowCell('${row.id}', 'PartName', this.value)" placeholder="e.g. NAND IC" class="spreadsheet-input text-zinc-600 truncate">
      </div>
      <div>
        <input type="number" value="${row.rawShortQty !== undefined ? row.rawShortQty : row.ShortQty}" oninput="updateSpreadsheetRowCell('${row.id}', 'ShortQty', this.value)" placeholder="Qty" class="spreadsheet-input font-mono text-zinc-800 font-bold">
      </div>
      <div>
        <input type="text" value="${row.MMO}" oninput="updateSpreadsheetRowCell('${row.id}', 'MMO', this.value)" placeholder="e.g. MMOB-260..." class="spreadsheet-input font-mono text-[#1F2937]">
      </div>
      <div class="flex justify-center">
        <button onclick="deleteSpreadsheetRow('${row.id}')" class="p-1 text-zinc-400 hover:text-rose-600 rounded transition-colors cursor-pointer" title="Delete Row">
          <i data-lucide="trash-2" class="h-3.5 w-3.5"></i>
        </button>
      </div>
    `;
    tbody.appendChild(tr);
  });
  
  lucide.createIcons();
}

function populateMappingSelect(id, headers, activeIndex, hasNone = false) {
  const select = document.getElementById(id);
  select.innerHTML = '';
  
  if (hasNone) {
    const opt = document.createElement('option');
    opt.value = -1;
    opt.innerText = `-- ${locale === 'th' ? 'ไม่มี' : 'None'} --`;
    select.appendChild(opt);
  }
  
  headers.forEach((header, idx) => {
    const opt = document.createElement('option');
    opt.value = idx;
    opt.innerText = header;
    if (idx === activeIndex) opt.selected = true;
    select.appendChild(opt);
  });
}

function onMappingSelectorChange(type) {
  const activeFile = excelFiles.find(f => f.id === activeExcelFileId);
  const sheet = excelSheets[activeExcelFileId];
  if (!activeFile || !sheet) return;
  
  const mapSelectPn = document.getElementById('map-select-pn');
  const mapSelectDesc = document.getElementById('map-select-desc');
  const mapSelectQty = document.getElementById('map-select-qty');
  const mapSelectMmo = document.getElementById('map-select-mmo');
  
  const pnIdx = Number(mapSelectPn.value);
  const nameIdx = Number(mapSelectDesc.value);
  const qtyIdx = Number(mapSelectQty.value);
  const mmoIdx = Number(mapSelectMmo.value);
  
  const parsed = parseRowsFromSheet(sheet.data, pnIdx, qtyIdx, mmoIdx, nameIdx, 1, activeFile.name);
  
  activeFile.pnColIndex = pnIdx;
  activeFile.nameColIndex = nameIdx;
  activeFile.qtyColIndex = qtyIdx;
  activeFile.mmoColIndex = mmoIdx;
  activeFile.rows = parsed;
  
  renderAll();
}

// Render Email Outputs
function renderEmailOutputs() {
  const countPns = document.getElementById('email-pns-count');
  const countMmos = document.getElementById('email-mmos-count');
  const filesContainer = document.getElementById('email-files-container');
  const filesList = document.getElementById('email-files-list');
  const btnClear = document.getElementById('btn-clear-email');
  
  countPns.innerText = emailData.pns.length;
  countMmos.innerText = emailData.mmos.length;

  if (uploadedEmailFiles.length === 0) {
    filesContainer.classList.add('hidden');
    btnClear.classList.add('hidden');
    document.getElementById('email-upload-icon').className = 'h-4 w-4 text-4B5563';
    document.getElementById('email-file-dropzone').className = 'h-24 border border-dashed border-[#D1D5DB] hover:border-[#9CA3AF] bg-[#F8F9FA] rounded flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors p-2';
  } else {
    filesContainer.classList.remove('hidden');
    btnClear.classList.remove('hidden');
    document.getElementById('email-upload-icon').className = 'h-4 w-4 text-[#10B981]';
    document.getElementById('email-file-dropzone').className = 'h-24 border border-dashed border-[#10B981] bg-[#ECFDF5] rounded flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors p-2';
    
    filesList.innerHTML = '';
    uploadedEmailFiles.forEach(file => {
      const row = document.createElement('div');
      row.className = 'p-1.5 flex justify-between items-center text-[10px]';
      row.innerHTML = `
        <div class="flex items-center gap-1.5 overflow-hidden">
          <i data-lucide="file-text" class="h-3 w-3 text-[#4B5563] shrink-0"></i>
          <span class="font-medium text-[#1A1C1E] truncate" title="${file.name}">
            ${file.name}
          </span>
          <span class="text-[8px] px-1 py-0.2 bg-[#E5E7EB] text-[#4B5563] font-mono rounded shrink-0">
            ${file.pns.length} PNs | ${file.mmos.length} MMOs
          </span>
        </div>
        <button onclick="removeEmailFile('${file.id}', event)" class="p-1 hover:bg-rose-50 text-rose-600 rounded transition-colors cursor-pointer" title="Remove file">
          <i data-lucide="trash-2" class="h-3 w-3"></i>
        </button>
      `;
      filesList.appendChild(row);
    });
  }
  
  // Render Chips
  const pnsChipsBox = document.getElementById('email-pns-chips-box');
  const mmosChipsBox = document.getElementById('email-mmos-chips-box');
  
  if (emailData.pns.length > 0) {
    pnsChipsBox.classList.remove('hidden');
    pnsChipsBox.classList.add('flex');
    pnsChipsBox.innerHTML = '';
    emailData.pns.slice(0, 15).forEach(pn => {
      pnsChipsBox.innerHTML += `<span class="chip font-mono">${pn}</span>`;
    });
    if (emailData.pns.length > 15) {
      pnsChipsBox.innerHTML += `<span class="text-[9px] text-[#9CA3AF] px-1 font-bold uppercase">+${emailData.pns.length - 15} ${locale === 'th' ? 'รายการเพิ่มเติม' : 'MORE'}</span>`;
    }
  } else {
    pnsChipsBox.classList.add('hidden');
  }

  if (emailData.mmos.length > 0) {
    mmosChipsBox.classList.remove('hidden');
    mmosChipsBox.classList.add('flex');
    mmosChipsBox.innerHTML = '';
    emailData.mmos.slice(0, 15).forEach(mmo => {
      mmosChipsBox.innerHTML += `<span class="chip font-mono">${mmo}</span>`;
    });
    if (emailData.mmos.length > 15) {
      mmosChipsBox.innerHTML += `<span class="text-[9px] text-[#9CA3AF] px-1 font-bold uppercase">+${emailData.mmos.length - 15} ${locale === 'th' ? 'รายการเพิ่มเติม' : 'MORE'}</span>`;
    }
  } else {
    mmosChipsBox.classList.add('hidden');
  }
  
  lucide.createIcons();
}

// Render Results display block
function renderResultsPanel(results) {
  const emptyResults = document.getElementById('results-empty-placeholder');
  const resultsContent = document.getElementById('results-content');
  const actionsGroup = document.getElementById('export-actions-group');
  
  if (results.length === 0) {
    emptyResults.classList.remove('hidden');
    resultsContent.classList.add('hidden');
    actionsGroup.classList.add('hidden');
    return;
  }
  
  emptyResults.classList.add('hidden');
  resultsContent.classList.remove('hidden');
  actionsGroup.classList.remove('hidden');
  
  // Group results by MMO
  const mmoGroups = getResultsGroupedByMmo(results);
  
  // 1. Sync active MMO tab selector
  if (mmoGroups.length > 0) {
    const exists = mmoGroups.some(g => g.mmo === activeMmoTab);
    if (!exists) {
      activeMmoTab = mmoGroups[0].mmo;
    }
  } else {
    activeMmoTab = '';
  }
  
  // 2. Render MMO tabs list
  const mmoTabGroupsContainer = document.getElementById('mmo-tab-groups-container');
  const mmoTabsRow = document.getElementById('mmo-tabs-row');
  
  if (mmoGroups.length > 1) {
    mmoTabGroupsContainer.classList.remove('hidden');
    mmoTabsRow.innerHTML = '';
    mmoGroups.forEach(g => {
      const isAct = g.mmo === activeMmoTab;
      const displayMmo = g.mmo === 'Unknown MMO' ? translations.unknown_mmo[locale] : g.mmo;
      
      const btn = document.createElement('button');
      btn.onclick = () => {
        activeMmoTab = g.mmo;
        refreshReportFieldsDefault();
        renderAll();
      };
      btn.className = `px-3 py-1.5 text-xs font-bold rounded border transition-all uppercase tracking-wide cursor-pointer ${
        isAct
          ? 'bg-[#112E51] text-white border-[#112E51] shadow-md scale-[1.02]'
          : 'bg-zinc-50 hover:bg-zinc-100 text-zinc-700 border-zinc-200'
      }`;
      btn.innerText = `📂 ${displayMmo} (${g.total} ${locale === 'th' ? 'พาร์ท' : 'PNs'})`;
      mmoTabsRow.appendChild(btn);
    });
  } else {
    mmoTabGroupsContainer.classList.add('hidden');
  }
  
  // Render Corporate report view
  renderReportSlide(results, mmoGroups);
  
  // Render Status Matrix Database view
  renderDatabaseMatrix(results);
}

// 7. EXECUTIVE SUMMARY SLIDE PREVIEW ROUTINE
function refreshReportFieldsDefault() {
  const results = computeReconciliationResults();
  const mmoGroups = getResultsGroupedByMmo(results);
  const activeGroup = mmoGroups.find(g => g.mmo === activeMmoTab) || mmoGroups[0];
  
  if (!activeGroup) return;

  const currentMmo = activeGroup.mmo === 'Unknown MMO' ? translations.unknown_mmo[locale] : activeGroup.mmo;
  customReportBomRef = currentMmo;
  
  if (locale === 'th') {
    customReportTitle = 'รายงานความพร้อมชิ้นส่วน 4M';
    customReportPeriod = '22 มิ.ย. – 04 ก.ค. 2026';
    customReportDate = new Date().toLocaleDateString('th-TH', { month: 'long', day: '2-digit', year: 'numeric' });
  } else {
    customReportTitle = '4M Material Readiness Report';
    customReportPeriod = 'Jun 22 – Jul 04, 2026';
    customReportDate = new Date().toLocaleDateString('en-US', { month: 'long', day: '2-digit', year: 'numeric' });
  }

  const firstAppeared = locale === 'th' ? "30 มิถุนายน" : "June 30";
  const daysElapsed = locale === 'th' ? "8 วัน" : "8 days";
  const firstEmail = locale === 'th' ? "22 มิ.ย." : "Jun 22";

  customReportBullet1 = locale === 'th'
    ? `ใบสั่งผลิต ${currentMmo} ปรากฏตัวครั้งแรกในอีเมลแจ้งของขาดเมื่อวันที่ ${firstAppeared} (${daysElapsed} หลังจากอีเมลฉบับแรกในชุดข้อมูล, ${firstEmail})`
    : `${currentMmo} first appeared in the shortage email on ${firstAppeared} (${daysElapsed} after the first email in the series, ${firstEmail}).`;

  const criticalPart = activeGroup.pns.find(r => r.status === '1st');
  if (criticalPart) {
    const pName = criticalPart.PartName || (locale === 'th' ? 'ชิปหน่วยความจำ NAND, LONGSYS' : 'NAND IC, LONGSYS');
    customReportBullet2 = locale === 'th'
      ? `ชิ้นส่วนวิกฤต: ${criticalPart.PN} (${pName}) — ขาด ${criticalPart.ShortQty} ชิ้น, ส่งมอบแล้ว 0 ชิ้น`
      : `Critical part: ${criticalPart.PN} (${pName}) — Short ${criticalPart.ShortQty} pcs, Issued 0 pcs.`;
  } else {
    customReportBullet2 = locale === 'th'
      ? `ชิ้นส่วนวิกฤต: ไม่พบข้อมูลรายการพาร์ทขาดแคลนระดับที่ 1 (วิกฤต) ที่ตรงกันในชุดข้อมูลนี้`
      : `Critical part: No confirmed matched 1st Priority (Critical) shortages found in this dataset.`;
  }

  customReportBullet3 = locale === 'th'
    ? `กำหนดการจัดส่งยังไม่ได้รับการยืนยัน ณ วันที่ส่งอีเมลล่าสุด (4 กรกฎาคม) — วันตามแผน PC เลื่อนออกไปแล้ว 3 ครั้ง`
    : `Delivery remains unconfirmed as of the latest email (July 4) — PC Plan date has been pushed back 3 times.`;

  // Sync inputs
  document.getElementById('inp-report-title').value = customReportTitle;
  document.getElementById('inp-report-bom-ref').value = customReportBomRef;
  document.getElementById('inp-report-period').value = customReportPeriod;
  document.getElementById('inp-report-date').value = customReportDate;
  document.getElementById('inp-report-bullet1').value = customReportBullet1;
  document.getElementById('inp-report-bullet2').value = customReportBullet2;
  document.getElementById('inp-report-bullet3').value = customReportBullet3;

  updateReportTextLive();
}

function updateReportTextLive() {
  customReportTitle = document.getElementById('inp-report-title').value;
  customReportBomRef = document.getElementById('inp-report-bom-ref').value;
  customReportPeriod = document.getElementById('inp-report-period').value;
  customReportDate = document.getElementById('inp-report-date').value;
  customReportBullet1 = document.getElementById('inp-report-bullet1').value;
  customReportBullet2 = document.getElementById('inp-report-bullet2').value;
  customReportBullet3 = document.getElementById('inp-report-bullet3').value;

  // Render on slide page 1
  document.getElementById('slide-preview-title').innerText = customReportTitle;
  document.getElementById('slide-preview-bom-ref').innerText = customReportBomRef;
  document.getElementById('slide-preview-date').innerText = customReportDate;
  document.getElementById('slide-preview-bullet1').innerText = customReportBullet1;
  document.getElementById('slide-preview-bullet2').innerText = customReportBullet2;
  document.getElementById('slide-preview-bullet3').innerText = customReportBullet3;
}

function renderReportSlide(results, mmoGroups) {
  const activeGroup = mmoGroups.find(g => g.mmo === activeMmoTab) || mmoGroups[0];
  if (!activeGroup) return;

  const total = activeGroup.total;
  const critical = activeGroup.first;
  const discrepancy = activeGroup.second;
  const goodNr = activeGroup.good + activeGroup.notReported;

  // Ingest KPIs
  document.getElementById('slide-kpi-total').innerText = total;
  document.getElementById('slide-kpi-critical').innerText = critical;
  document.getElementById('slide-kpi-healthy').innerText = goodNr;

  // SVG Pie chart rendering
  renderDonutChart('donut-svg-wrapper', critical, discrepancy, goodNr);

  // Narrative summary calculation
  const mmoCount = mmoGroups.length;
  let text = '';
  if (locale === 'th') {
    text = `รายงานการกระทบยอดสรุปนี้วิเคราะห์ชิ้นส่วนที่ขาดแคลนทั้งหมดในกลุ่มใบสั่งผลิต "${activeGroup.mmo === 'Unknown MMO' ? translations.unknown_mmo[locale] : activeGroup.mmo}" โดยตรวจพบพาร์ทขาดรวม ${total} รายการ ซึ่งมี ${critical} รายการตรงกับรายงานของขาดวิกฤตในอีเมล และ ${discrepancy} รายการมีความไม่สอดคล้องกัน แนะนำให้เร่งจัดการประสานงานด่วน`;
  } else {
    text = `This reconciliation report summarizes shortages inside MMO group "${activeGroup.mmo === 'Unknown MMO' ? translations.unknown_mmo[locale] : activeGroup.mmo}". A total of ${total} parts are checked. Crucially, ${critical} items match both sources (Need to Check), and ${discrepancy} item(s) are listed exclusively in emails. Immediate expediting is recommended.`;
  }
  document.getElementById('slide-preview-narrative').innerText = text;

  // Partition detailed rows table into paginated PDF Pages (23 rows per page max)
  const rowsPerPage = 23;
  const pages = [];
  const pns = activeGroup.pns;
  for (let i = 0; i < pns.length; i += rowsPerPage) {
    pages.push(pns.slice(i, i + rowsPerPage));
  }

  // Update slide pages counts indicators
  document.getElementById('preview-page-count').innerText = 1 + pages.length;

  // Render Page 2+ Detailed Tables
  const dynContainer = document.getElementById('pdf-dynamic-tables-container');
  dynContainer.innerHTML = '';

  pages.forEach((pageRows, pageIdx) => {
    const tableSlide = document.createElement('div');
    tableSlide.id = `report-page-table-${pageIdx}`;
    tableSlide.className = 'bg-white shadow-lg border border-zinc-300 rounded font-sans flex flex-col justify-between select-none shrink-0';
    tableSlide.style.width = '700px';
    tableSlide.style.height = '989px';
    tableSlide.style.padding = '36px';
    tableSlide.style.boxSizing = 'border-box';

    let tableRowsHtml = '';
    pageRows.forEach(row => {
      let statusBadge = '';
      if (row.status === '1st') {
        statusBadge = '<span class="status-badge bg-rose-50 text-rose-700 border-rose-200">Need to Check</span>';
      } else if (row.status === '2nd') {
        statusBadge = '<span class="status-badge bg-amber-50 text-amber-700 border-amber-200">2nd</span>';
      } else {
        statusBadge = '<span class="status-badge bg-emerald-50 text-emerald-700 border-emerald-200">Good / NR</span>';
      }

      tableRowsHtml += `
        <div class="grid grid-cols-[1.5fr_2fr_1fr_1.2fr_1.2fr] gap-2 px-3 py-1.5 items-center hover:bg-zinc-50 border-b border-zinc-100 text-[10px]">
          <div class="font-mono text-zinc-800 font-medium">${row.PN}</div>
          <div class="truncate text-zinc-500 font-medium" title="${row.PartName || ''}">${row.PartName || '-'}</div>
          <div class="font-mono font-bold ${row.ShortQty > 0 ? 'text-zinc-800' : 'text-zinc-400'}">${row.ShortQty > 0 ? row.ShortQty.toLocaleString() : '-'}</div>
          <div class="font-mono text-zinc-600 truncate">${row.MMO}</div>
          <div class="flex">${statusBadge}</div>
        </div>
      `;
    });

    tableSlide.innerHTML = `
      <div class="space-y-4">
        <!-- Header -->
        <div class="border-b-2 border-zinc-800 pb-2.5">
          <div class="flex justify-between items-center">
            <h2 class="text-sm font-black uppercase tracking-tight text-[#112E51]">
              ${customReportTitle}
            </h2>
            <span class="text-[9px] bg-zinc-800 text-white font-mono px-2 py-0.5 rounded font-black uppercase tracking-wider">
              ${activeGroup.mmo === 'Unknown MMO' ? translations.unknown_mmo[locale] : activeGroup.mmo}
            </span>
          </div>
          <p class="text-[9px] text-zinc-400 mt-1 uppercase font-bold tracking-wider">
            ${locale === 'th' ? 'ภาคผนวก: ตารางตรวจสอบความสอดคล้องชิ้นส่วนอย่างละเอียด' : 'Appendix: Detailed Material Reconciliation Matrix'}
          </p>
        </div>

        <!-- Table Grid -->
        <div class="border border-zinc-200 rounded overflow-hidden flex flex-col bg-white">
          <!-- Head -->
          <div class="grid grid-cols-[1.5fr_2fr_1fr_1.2fr_1.2fr] gap-2 px-3 py-2 bg-zinc-800 text-white text-[9px] font-black uppercase tracking-wider">
            <div>${translations.map_pn[locale]}</div>
            <div>${translations.map_desc[locale]}</div>
            <div>${translations.map_qty[locale]}</div>
            <div>${translations.map_mmo[locale]}</div>
            <div>${locale === 'th' ? 'สถานะการตรวจสอบ' : 'STATUS'}</div>
          </div>
          <!-- Body -->
          <div class="flex-1 flex flex-col">
            ${tableRowsHtml}
          </div>
        </div>
      </div>

      <!-- Footer -->
      <div class="border-t border-zinc-200 pt-2 flex justify-between items-center text-[8px] font-bold uppercase tracking-widest text-zinc-400">
        <span>${translations.slide_footer_left[locale]}</span>
        <span>Page ${2 + pageIdx} of ${1 + pages.length}</span>
      </div>
    `;

    dynContainer.appendChild(tableSlide);
  });
}

function renderDonutChart(containerId, first, second, good) {
  const container = document.getElementById(containerId);
  const total = first + second + good;
  
  if (total === 0) {
    container.innerHTML = `
      <svg width="110" height="110" viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="38" fill="none" stroke="#E5E7EB" strokeWidth="16" />
        <text x="50" y="54" textAnchor="middle" class="text-[9px] font-mono fill-zinc-400">NO DATA</text>
      </svg>
    `;
    return;
  }

  const data = [
    { value: first, color: '#EF4444' }, // Red
    { value: second, color: '#F59E0B' }, // Yellow
    { value: good, color: '#10B981' }   // Green
  ].filter(d => d.value > 0);

  let accumulatedAngle = 0;
  const radius = 38;
  const center = 50;
  let paths = '';

  data.forEach((slice, index) => {
    const percentage = (slice.value / total) * 100;
    const angle = (slice.value / total) * 360;
    
    const x1 = center + radius * Math.cos((accumulatedAngle - 90) * Math.PI / 180);
    const y1 = center + radius * Math.sin((accumulatedAngle - 90) * Math.PI / 180);
    
    accumulatedAngle += angle;
    
    const x2 = center + radius * Math.cos((accumulatedAngle - 90) * Math.PI / 180);
    const y2 = center + radius * Math.sin((accumulatedAngle - 90) * Math.PI / 180);
    
    const largeArcFlag = angle > 180 ? 1 : 0;
    
    const pathData = Math.abs(percentage - 100) < 0.01
      ? `M 50 12 A 38 38 0 1 1 49.99 12 Z`
      : `M ${center} ${center} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2} Z`;

    const labelAngle = accumulatedAngle - (angle / 2) - 90;
    const labelRadius = radius * 0.65;
    const lx = center + labelRadius * Math.cos(labelAngle * Math.PI / 180);
    const ly = center + labelRadius * Math.sin(labelAngle * Math.PI / 180);

    const percentText = percentage > 4 
      ? `<text x="${lx}" y="${ly + 2}" text-anchor="middle" fill="#ffffff" style="font-size: 6.5px; font-weight: 900; pointer-events: none;">${Math.round(percentage)}%</text>`
      : '';

    paths += `
      <g>
        <path d="${pathData}" fill="${slice.color}" stroke="#ffffff" stroke-width="2" />
        ${percentText}
      </g>
    `;
  });

  container.innerHTML = `
    <svg width="150" height="150" viewBox="0 0 100 100" style="overflow: visible;">
      ${paths}
      <circle cx="50" cy="50" r="23" fill="#ffffff" stroke="#F1F3F5" stroke-width="1" />
      <text x="50" y="47" text-anchor="middle" fill="#9CA3AF" style="font-size: 6.5px; font-weight: bold; letter-spacing: 0.1em; text-transform: uppercase;">Total</text>
      <text x="50" y="58" text-anchor="middle" fill="#1A1C1E" style="font-size: 12px; font-weight: 900;">${total}</text>
    </svg>
  `;
}

// 8. DATABASE MATRIX VIEW ROUTINE
let searchTerm = '';
let statusFilterValue = 'ALL';

function applyDatabaseFilters() {
  searchTerm = document.getElementById('db-search-input').value.toLowerCase();
  statusFilterValue = document.getElementById('db-status-filter').value;
  
  const results = computeReconciliationResults();
  renderDatabaseMatrix(results);
}

function renderDatabaseMatrix(results) {
  const tbody = document.getElementById('db-table-body');
  tbody.innerHTML = '';
  
  const filtered = results.filter(row => {
    const matchSearch = row.PN.toLowerCase().includes(searchTerm) || 
                        row.MMO.toLowerCase().includes(searchTerm) || 
                        (row.PartName && row.PartName.toLowerCase().includes(searchTerm));
                        
    const matchStatus = statusFilterValue === 'ALL' || row.status === statusFilterValue;
    return matchSearch && matchStatus;
  });

  document.getElementById('db-showing-count').innerText = filtered.length;
  document.getElementById('db-total-count').innerText = results.length;

  const hint = document.getElementById('db-filtered-hint');
  if (filtered.length !== results.length) {
    hint.innerText = `* FILTERED`;
  } else {
    hint.innerText = '';
  }

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <div class="py-16 text-center text-zinc-400 flex flex-col items-center justify-center gap-1.5 flex-1">
        <i data-lucide="help-circle" class="h-8 w-8 text-zinc-300"></i>
        <p class="font-bold text-xs text-[#4B5563] uppercase">${locale === 'th' ? 'ไม่พบข้อมูลที่ตรงเงื่อนไข' : 'No records found'}</p>
        <p class="text-[10px]">${locale === 'th' ? 'ทดลองกรองข้อมูลด้วยคำสำคัญอื่น' : 'Try searching or filtering with other keys.'}</p>
      </div>
    `;
    lucide.createIcons();
    return;
  }

  filtered.forEach(row => {
    let statusClass = '';
    let statusText = '';
    
    if (row.status === '1st') {
      statusClass = 'bg-rose-50 text-rose-700 border-rose-200';
      statusText = 'Need to Check';
    } else if (row.status === '2nd') {
      statusClass = 'bg-amber-50 text-amber-700 border-amber-200';
      statusText = '2nd';
    } else {
      statusClass = 'bg-emerald-50 text-emerald-700 border-emerald-200';
      statusText = 'Good / NR';
    }

    const tr = document.createElement('div');
    tr.className = 'grid grid-cols-[1.5fr_2fr_1fr_1.2fr_1.2fr] gap-2.5 px-4 py-2 items-center hover:bg-zinc-50 border-b border-zinc-100';
    tr.innerHTML = `
      <div class="font-mono text-zinc-800 font-bold tracking-tight select-all">${row.PN}</div>
      <div class="truncate text-zinc-500 font-medium" title="${row.PartName || ''}">${row.PartName || '-'}</div>
      <div class="font-mono font-bold text-zinc-800">${row.ShortQty > 0 ? row.ShortQty.toLocaleString() : '-'}</div>
      <div class="font-mono text-zinc-600 select-all">${row.MMO}</div>
      <div class="flex"><span class="status-badge ${statusClass}">${statusText}</span></div>
    `;
    tbody.appendChild(tr);
  });
}

// Spreadsheet row cell updates handler
function updateSpreadsheetRowCell(rowId, field, val) {
  excelFiles = excelFiles.map(file => {
    const updatedRows = file.rows.map(row => {
      if (row.id === rowId) {
        if (field === 'ShortQty') {
          const num = parseShortQty(val);
          return { ...row, ShortQty: num, rawShortQty: val };
        }
        return { ...row, [field]: val };
      }
      return row;
    });
    return { ...file, rows: updatedRows };
  });
  
  // Real-time recalculation without refresh lag
  const results = computeReconciliationResults();
  renderResultsPanel(results);
}

// Delete spreadsheet row
function deleteSpreadsheetRow(rowId) {
  excelFiles = excelFiles.map(file => {
    return {
      ...file,
      rows: file.rows.filter(r => r.id !== rowId)
    };
  });
  renderAll();
}

// Add empty manual spreadsheet row
function addManualRow() {
  const activeFile = excelFiles.find(f => f.id === activeExcelFileId);
  if (!activeFile) return;
  
  const defMmo = activeFile.name.replace(/\.[^/.]+$/, "").trim();
  const newRow = {
    id: 'row-' + Math.random().toString(36).substring(2, 9),
    PN: '',
    ShortQty: 0,
    MMO: defMmo,
    PartName: ''
  };
  
  activeFile.rows.push(newRow);
  renderAll();
}

function deleteExcelFile(fileId, e) {
  if (e) e.stopPropagation();
  excelFiles = excelFiles.filter(f => f.id !== fileId);
  delete excelSheets[fileId];
  if (activeExcelFileId === fileId) {
    activeExcelFileId = excelFiles.length > 0 ? excelFiles[0].id : null;
  }
  renderAll();
}

function clearAllExcelFiles() {
  excelFiles = [];
  excelSheets = {};
  activeExcelFileId = null;
  renderAll();
}

// 9. EXPORT & DOWNLOAD ACTIONS
function copyToClipboardTSV() {
  const results = computeReconciliationResults();
  if (results.length === 0) return;

  const headers = ['PN', 'Part Name', 'MMO', 'ShortQty', 'Status'];
  const rows = results.map(r => [r.PN, r.PartName || '', r.MMO, r.ShortQty, r.status].join('\t'));
  const fullText = [headers.join('\t'), ...rows].join('\n');

  navigator.clipboard.writeText(fullText).then(() => {
    alert(locale === 'th' ? "คัดลอกข้อมูลตารางลงคลิปบอร์ดแล้ว" : "Reconciliation status matrix copied to clipboard!");
  });
}

function exportResultsToCSV() {
  const results = computeReconciliationResults();
  if (results.length === 0) return;

  const headers = ['PN', 'PartName', 'MMO', 'ShortQty', 'Status'];
  const csvRows = [
    headers.join(','),
    ...results.map(row => [
      `"${row.PN.replace(/"/g, '""')}"`,
      `"${(row.PartName || '').replace(/"/g, '""')}"`,
      `"${row.MMO.replace(/"/g, '""')}"`,
      row.ShortQty,
      `"${row.status}"`
    ].join(','))
  ];

  const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `shortage_reconciliation_${customReportBomRef}_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Multi-page PDF Generator using html2canvas & jsPDF
async function generateExecutivePDF() {
  const results = computeReconciliationResults();
  if (results.length === 0) return;

  const btn = document.getElementById('btn-pdf-export');
  const icon = document.getElementById('pdf-btn-icon');
  const txt = document.getElementById('txt-btn-pdf');
  
  btn.disabled = true;
  txt.innerText = locale === 'th' ? "กำลังสร้าง..." : "Compiling...";
  
  try {
    const page1 = document.getElementById('report-page-1');
    const mmoGroups = getResultsGroupedByMmo(results);
    const activeGroup = mmoGroups.find(g => g.mmo === activeMmoTab) || mmoGroups[0];
    
    // Pages calculation
    const rowsPerPage = 23;
    const pagesCount = Math.ceil(activeGroup.pns.length / rowsPerPage);
    const tableElements = [];
    
    for (let i = 0; i < pagesCount; i++) {
      const el = document.getElementById(`report-page-table-${i}`);
      if (el) tableElements.push(el);
    }

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgWidth = 210; // A4 width in mm

    // Render Page 1 Slide
    const canvas1 = await html2canvas(page1, {
      scale: 2.2, // crisp resolution
      useCORS: true,
      backgroundColor: '#ffffff',
      windowWidth: 800
    });
    
    const imgData1 = canvas1.toDataURL('image/png');
    const imgHeight1 = (canvas1.height * imgWidth) / canvas1.width;
    pdf.addImage(imgData1, 'PNG', 0, 0, imgWidth, imgHeight1);

    // Render Table Pages
    for (let idx = 0; idx < tableElements.length; idx++) {
      const canvasT = await html2canvas(tableElements[idx], {
        scale: 2.2,
        useCORS: true,
        backgroundColor: '#ffffff',
        windowWidth: 800
      });
      pdf.addPage();
      const imgDataT = canvasT.toDataURL('image/png');
      const imgHeightT = (canvasT.height * imgWidth) / canvasT.width;
      pdf.addImage(imgDataT, 'PNG', 0, 0, imgWidth, imgHeightT);
    }

    pdf.save(`4M_Readiness_Report_${customReportBomRef}_${new Date().toISOString().split('T')[0]}.pdf`);
  } catch (err) {
    console.error(err);
    alert("Failed to generate PDF. Check console.");
  } finally {
    btn.disabled = false;
    txt.innerText = locale === 'th' ? 'ส่งออก PDF' : 'PDF Report';
  }
}

// 10. LOAD DEMO DATASET SIMULATOR
function loadDemoDataset() {
  const demoExcelRows = [
    { id: '1', PN: '73DIFF0001C0644', ShortQty: 34, MMO: 'MMOB-2606000091', PartName: 'NAND IC,SDWFR-1T00B53IEC,TLC,8DIE,4CE,2CH,LONGSYS' },
    { id: '2', PN: '2120000023H1', ShortQty: 1428, MMO: 'MMOB-2606000091', PartName: 'SOLDERING PASTE, SAC8903, SN-3.0AG-0.5CU' },
    { id: '3', PN: '2210000010H1', ShortQty: 0, MMO: 'MMOB-2606000091', PartName: 'BOMDING ADHESIVE,SEALING MATERIAL,UNDERFILL' },
    { id: '4', PN: '2450000034M0', ShortQty: 0, MMO: 'MMOB-2606000091', PartName: 'CARBON BELT,RIBBON B110CR(55MM*300M) BLACK' },
    { id: '5', PN: '6095001275AH0', ShortQty: 1, MMO: 'MMOB-2606000091', PartName: 'LABEL,SAFETY,CSZ, [GENERAL] REV:A(HF)' },
    { id: '6', PN: '6095002944AH0', ShortQty: 17, MMO: 'MMOB-2606000091', PartName: 'LABEL,PCBA(FOR SMT),WHITE 40MM*8MM, MAT\'L:WHITE PET' },
    { id: '7', PN: '6095003586AH0', ShortQty: 18, MMO: 'MMOB-2606000091', PartName: 'LABEL,GREEN PCBA LABEL FOR SINGLE LINE FOR SMT' },
    { id: '8', PN: '710A00040C0H1', ShortQty: 17, MMO: 'MMOB-2606000091', PartName: 'ANALOG IC,2.7-22V,0.7-5A,CURRENT LIMIT SWITCH' },
    { id: '9', PN: '710A0020190H1', ShortQty: 51, MMO: 'MMOB-2606000091', PartName: 'ANALOG IC,ACTIVE,DC TO DC 5.5V/2A 2.4MHZ SOT-563' },
    { id: '10', PN: '710A0020390H1', ShortQty: 17, MMO: 'MMOB-2606000091', PartName: 'ANALOG IC, REGULATOR 3.3V 0.3A, DFN4 1X1MM' }
  ];

  // Ingest additional dummy elements to fill 53 components total to mirror original screenshot exactly
  for (let idx = 11; idx <= 53; idx++) {
    const pNum = 8000000000 + idx;
    demoExcelRows.push({
      id: 'row-' + idx,
      PN: `${pNum}H1`,
      ShortQty: Math.random() > 0.72 ? Math.floor(Math.random() * 20) + 1 : 0,
      MMO: 'MMOB-2606000091',
      PartName: `GENERAL SMT CAPACITOR / RESISTOR ELEMENT TYPE-${idx - 10}`
    });
  }

  const demoExcelFile = {
    id: 'demo-excel-1',
    name: 'MMO-9092_shortage.xlsx',
    rows: demoExcelRows,
    pnColIndex: 0,
    qtyColIndex: 1,
    mmoColIndex: 2,
    nameColIndex: 3
  };

  excelFiles = [demoExcelFile];
  activeExcelFileId = 'demo-excel-1';

  emailData = {
    pns: ['73DIFF0001C0644'], // Critical match PN
    mmos: ['MMOB-2606000091'],
    rawPns: '73DIFF0001C0644',
    rawMmos: 'MMOB-2606000091',
    pnToMmoMap: { '73diff0001c0644': 'MMOB-2606000091' }
  };

  document.getElementById('email-pns-textarea').value = emailData.rawPns;
  document.getElementById('email-mmos-textarea').value = emailData.rawMmos;

  // Clear file lists and errors
  uploadedEmailFiles = [];
  hideExcelError();
  hideEmailError();

  // Load defaults
  refreshReportFieldsDefault();
  renderAll();

  // Hide the "Demo Data" button from header once loaded
  document.getElementById('btn-load-demo').classList.add('hidden');
}
