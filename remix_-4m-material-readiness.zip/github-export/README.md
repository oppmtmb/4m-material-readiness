# 📊 Material Shortage Reconciliation & Analytics Tool

A high-fidelity, standalone, fully-functional web-based material procurement reconciliation utility. This engine is designed to instantly compare system inventory shortage list spreadsheets against urgent email status report logs, identifying and grouping parts into clear priority statuses.

It is structured to be completely **standalone, portable, and GitHub-ready**—meaning you can host it directly on **GitHub Pages**, run it inside an offline enterprise environment, or double-click to open it locally inside any modern browser without any node_modules installation.

---

## 🛠️ Features
- **📊 Real-time Reconciliation Engine**: Sets priority levels dynamically using multi-source comparisons.
- **🇹🇭/🇺🇸 Dual-Language Translation**: Seamlessly switch between **Thai (TH)** and **English (EN)** locales in a single-click.
- **📋 PDF Executive Presentation Slide**: Generates an A4-proportioned corporate presentation slide deck complete with:
  - KPI metric count cards.
  - Interactive summary findings.
  - Dynamically generated SVG donut chart distributions.
  - Appendix tables elegantly paginated (23 rows max) to prevent printing overflows.
- **📥 Multiple Import Options**:
  - Drag-and-drop or file upload multiple `.xlsx` or `.csv` shortage files (SheetJS powered).
  - Drag-and-drop Outlook `.msg` message files or `.eml` emails to auto-extract PNs and MMO codes.
  - Paste and parse raw text tables from clipboards directly.
- **✍️ Interactive Cell Editor**: Double-click or type inside the active spreadsheets grid to change Part Numbers, descriptions, Short quantities, or MMO tags in real time.
- **📂 Multitasking MMO Tabs**: Seamlessly switch report datasets by active Production Order MMO folders.

---

## 📂 Repository Structure
```
├── index.html       # Primary UI structure styled with Tailwind & loaded via CDN
├── style.css        # Sizing boundaries, transitions, and A4 print dimensions layout
├── script.js        # Core reconciliation calculations, file parsers, and PDF exporters
└── README.md        # Technical user guide and deployment directions (this file)
```

### Integrated CDN Dependencies (No Build Steps Needed!)
1. **Tailwind CSS v3**: Utility-first CSS frame.
2. **Lucide Icons**: Interactive vector interface indicators.
3. **SheetJS (xlsx.full.min.js)**: Client-side Excel `.xlsx` spreadsheet parser.
4. **html2canvas v1.4.1**: Renders pixel-perfect DOM elements to canvas.
5. **jsPDF v2.5.1**: Generates multi-page A4 PDF documents.
6. **MsgReader v1.28.0**: Client-side parsing for Compound File Binary Format Outlook `.msg` emails.

---

## 🚦 Getting Started

### Local Setup (Offline or Double-Click)
Since all libraries are loaded via reliable, cached public CDNs, there are **no compile steps**:
1. Clone or download this repository folder.
2. Double-click `index.html` to open it in Chrome, Safari, Edge, or Firefox.

### Host on GitHub Pages
To make this tool available to your entire procurement and supply chain team:
1. Create a new repository on GitHub.
2. Upload the `index.html`, `style.css`, and `script.js` files.
3. Navigate to **Settings** > **Pages**.
4. Set the build source to **Deploy from a branch**, select `main` (or `master`), and click **Save**.
5. Your application will be live at: `https://<your-username>.github.io/<repository-name>/`

---

## 📐 Reconciliation Analytics Logic Matrix

The matching engine processes inputs based on the following mathematical set formulas:

| Status Badge | Status Level | Formula & Venn Logic | Meaning / Action Required |
| :--- | :--- | :--- | :--- |
| **🔴 Need to Check** | **Priority 1 (Critical)** | $PN \in Email \land PN \in Excel \land ShortQty > 0$ | **CRITICAL**: The shortage is active on system records and has been raised as a deficit in the emails. Requires immediate expedite. |
| **🟡 2nd** | **Priority 2 (Conflict)** | $PN \in Email \land PN \notin Excel$ | **CONFLICT**: Urgent shortage exists in emails, but is missing from system Excel logs. Indicates data discrepancy. |
| **🟢 Good / NR** | **Priority 3 (Balanced)** | $Others$ | **GOOD**: Items either have $ShortQty \le 0$ or are absent in shortage emails. No immediate action required. |

---

## 💾 Demo Simulation Instructions
To test-drive the application immediately:
1. Click the **DEMO DATA** button in the top right-hand corner.
2. This simulates loading:
   - A shortage file named `MMO-9092_shortage.xlsx` with **53 active components**.
   - An email file with **73DIFF0001C0644** flagged.
3. Watch the interactive dashboard populate instantly, and click **PDF Report** to print the result.
